package com.kasikornbank.idva.ws.entity;

import java.util.ArrayList;
import java.util.Date;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class KBankHeaderResponse {

	private String funcNm;
	private String rqUID;
	private Date rsDt;
	private String rsAppId;
	private String rsUID;
	private String statusCode; // 00 = Success
	private String corrID;
	@XmlElement(required = true, nillable = true)
	private String reqAuthUserId;
	private int regAuthLevel;
	private ArrayList<Error> errorVect;

	public String getFuncNm() {
		return funcNm;
	}

	public void setFuncNm(String funcNm) {
		this.funcNm = funcNm;
	}

	public String getRqUID() {
		return rqUID;
	}

	public void setRqUID(String rqUID) {
		this.rqUID = rqUID;
	}

	public Date getRsDt() {
		return rsDt;
	}

	public void setRsDt(Date rsDt) {
		this.rsDt = rsDt;
	}

	public String getRsAppId() {
		return rsAppId;
	}

	public void setRsAppId(String rsAppId) {
		this.rsAppId = rsAppId;
	}

	public String getRsUID() {
		return rsUID;
	}

	public void setRsUID(String rsUID) {
		this.rsUID = rsUID;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getCorrID() {
		return corrID;
	}

	public void setCorrID(String corrID) {
		this.corrID = corrID;
	}

	public String getReqAuthUserId() {
		return reqAuthUserId;
	}

	public void setReqAuthUserId(String reqAuthUserId) {
		this.reqAuthUserId = reqAuthUserId;
	}

	public int getRegAuthLevel() {
		return regAuthLevel;
	}

	public void setRegAuthLevel(int regAuthLevel) {
		this.regAuthLevel = regAuthLevel;
	}

	public ArrayList<Error> getErrorVect() {
		return errorVect;
	}

	public void setErrorVect(ArrayList<Error> errorVect) {
		this.errorVect = errorVect;
	}

}
