package com.kasikornbank.idva.ws.entity;

public class Error {

	private String errorAppId;
	private String errorAppAbbrv;
	private String errorCode;
	private String errorDesc;
	private String errorSeverity;

	public Error() {
	}

	public Error(String errorAppId, String errorAppAbbrv, String errorCode, String errorDesc, String errorSeverity) {
		this.errorAppId = errorAppId;
		this.errorAppAbbrv = errorAppAbbrv;
		this.errorCode = errorCode;
		this.errorDesc = errorDesc;
		this.errorSeverity = errorSeverity;
	}

	public String getErrorAppId() {
		return errorAppId;
	}

	public void setErrorAppId(String errorAppId) {
		this.errorAppId = errorAppId;
	}

	public String getErrorAppAbbrv() {
		return errorAppAbbrv;
	}

	public void setErrorAppAbbrv(String errorAppAbbrv) {
		this.errorAppAbbrv = errorAppAbbrv;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getErrorSeverity() {
		return errorSeverity;
	}

	public void setErrorSeverity(String errorSeverity) {
		this.errorSeverity = errorSeverity;
	}

}
