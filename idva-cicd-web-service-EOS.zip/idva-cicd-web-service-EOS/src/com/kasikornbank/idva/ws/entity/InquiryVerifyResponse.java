package com.kasikornbank.idva.ws.entity;

import java.util.List;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

import com.kasikornbank.idva.backend.entity.DocumentResponse;


@XmlRootElement(name="InquiryVerifyResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType (propOrder={"kbankHeader","status","refId","referDocumentFlag","numberOfRefId","numberOfValid","numberOfInValid","documents"})
public class InquiryVerifyResponse {
	@XmlElement(required=true, nillable=true)
	private KBankHeaderResponse kbankHeader;
	@XmlElement(required=true, nillable=true)
	private String status;
	@XmlElement(required=true, nillable=true)
	private String refId;
	@XmlElement(required=true, nillable=true)
	private String referDocumentFlag;
	@XmlElement(required=true, nillable=true)
	private int numberOfRefId;
	@XmlElement(required=true, nillable=true)
	private int numberOfValid;
	@XmlElement(required=true, nillable=true)
	private int numberOfInValid;
	private List<DocumentResponse> documents;
	
	public KBankHeaderResponse getKbankHeader() {
		return kbankHeader;
	}
	public void setKbankHeader(KBankHeaderResponse kbankHeader) {
		this.kbankHeader = kbankHeader;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public String getReferDocumentFlag() {
		return referDocumentFlag;
	}
	public void setReferDocumentFlag(String referDocumentFlag) {
		this.referDocumentFlag = referDocumentFlag;
	}
	public int getNumberOfRefId() {
		return numberOfRefId;
	}
	public void setNumberOfRefId(int numberOfRefId) {
		this.numberOfRefId = numberOfRefId;
	}
	public int getNumberOfValid() {
		return numberOfValid;
	}
	public void setNumberOfValid(int numberOfValid) {
		this.numberOfValid = numberOfValid;
	}
	public int getNumberOfInValid() {
		return numberOfInValid;
	}
	public void setNumberOfInValid(int numberOfInValid) {
		this.numberOfInValid = numberOfInValid;
	}
	public List<DocumentResponse> getDocuments() {
		return documents;
	}
	public void setDocuments(List<DocumentResponse> documents) {
		this.documents = documents;
	}

	
	
}
