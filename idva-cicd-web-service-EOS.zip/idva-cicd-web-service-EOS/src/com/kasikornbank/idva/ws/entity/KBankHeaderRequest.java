package com.kasikornbank.idva.ws.entity;

import java.util.Date;

public class KBankHeaderRequest {

	private String funcNm;
	private String rqUID;
	private Date rqDt;
	private String rqAppId;
	private String userId;
	private String terminalId;
	private String userLangPref;
	private String corrID;
	private String authUserId;
	private int authLevel;

	public String getFuncNm() {
		return funcNm;
	}

	public void setFuncNm(String funcNm) {
		this.funcNm = funcNm;
	}

	public String getRqUID() {
		return rqUID;
	}

	public void setRqUID(String rqUID) {
		this.rqUID = rqUID;
	}

	public Date getRqDt() {
		return rqDt;
	}

	public void setRqDt(Date rqDt) {
		this.rqDt = rqDt;
	}

	public String getRqAppId() {
		return rqAppId;
	}

	public void setRqAppId(String rqAppId) {
		this.rqAppId = rqAppId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getUserLangPref() {
		return userLangPref;
	}

	public void setUserLangPref(String userLangPref) {
		this.userLangPref = userLangPref;
	}

	public String getCorrID() {
		return corrID;
	}

	public void setCorrID(String corrID) {
		this.corrID = corrID;
	}

	public String getAuthUserId() {
		return authUserId;
	}

	public void setAuthUserId(String authUserId) {
		this.authUserId = authUserId;
	}

	public int getAuthLevel() {
		return authLevel;
	}

	public void setAuthLevel(int authLevel) {
		this.authLevel = authLevel;
	}

}
