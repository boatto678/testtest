package com.kasikornbank.idva.ws.entity;

import java.util.List;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

import com.kasikornbank.idva.backend.entity.DocumentServiceResponse;
import com.kasikornbank.idva.backend.entity.SereviceResponse;


@XmlRootElement(name="InquiryVerifyByAccountNoResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType (propOrder={"kbankHeader","accountNo","refId","referDocumentFlag","numberOfRefId","numberOfValid","numberOfInValid","documents","services" })
public class InquiryVerifyByAccountNoResponse {
	@XmlElement(required=true, nillable=true)
	private KBankHeaderResponse kbankHeader;
	@XmlElement(required=true, nillable=true)
	private String accountNo;
	@XmlElement(required=true, nillable=true)
	private String refId;
	@XmlElement(required=true, nillable=true)
	private String referDocumentFlag;
	@XmlElement(required=true, nillable=true)
	private int numberOfRefId;
	@XmlElement(required=true, nillable=true)
	private int numberOfValid;
	@XmlElement(required=true, nillable=true)
	private int numberOfInValid;
	private List<DocumentServiceResponse> documents;
	private List<SereviceResponse> services;
	
	public KBankHeaderResponse getKbankHeader() {
		return kbankHeader;
	}
	public void setKbankHeader(KBankHeaderResponse kbankHeader) {
		this.kbankHeader = kbankHeader;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getRefId() {
		return refId;
	}
	public void setRefId(String refId) {
		this.refId = refId;
	}
	public String getReferDocumentFlag() {
		return referDocumentFlag;
	}
	public void setReferDocumentFlag(String referDocumentFlag) {
		this.referDocumentFlag = referDocumentFlag;
	}
	public int getNumberOfRefId() {
		return numberOfRefId;
	}
	public void setNumberOfRefId(int numberOfRefId) {
		this.numberOfRefId = numberOfRefId;
	}
	public int getNumberOfValid() {
		return numberOfValid;
	}
	public void setNumberOfValid(int numberOfValid) {
		this.numberOfValid = numberOfValid;
	}
	public int getNumberOfInValid() {
		return numberOfInValid;
	}
	public void setNumberOfInValid(int numberOfInValid) {
		this.numberOfInValid = numberOfInValid;
	}
	public List<DocumentServiceResponse> getDocuments() {
		return documents;
	}
	public void setDocuments(List<DocumentServiceResponse> documents) {
		this.documents = documents;
	}
	public List<SereviceResponse> getServices() {
		return services;
	}
	public void setServices(List<SereviceResponse> services) {
		this.services = services;
	}
	
}
