package com.kasikornbank.idva.ws.entity;

import java.util.List;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

import com.kasikornbank.idva.backend.entity.DocumentRequest;

@XmlRootElement(name = "InvalidateVerifyStatusRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "kbankHeader", "refId", "referDocumentFlag", "transDesc", "accountNo", "transTypeCode", "transTypeDesc", 
		"accountFund", "cis", "debitCard", "creditCard", "otherAcctType", "otherAcctNo", "documents" })
public class InvalidateVerifyStatusRequest {
	private String refId;
	private List<DocumentRequest> documents;
	private String referDocumentFlag;
	private String transDesc;
	private String accountNo;
	private KBankHeaderRequest kbankHeader;
	private String transTypeCode;
	private String transTypeDesc;
	private String accountFund;
	private String cis;
	private String debitCard;
	private String creditCard;
	private String otherAcctType;
	private String otherAcctNo;
	
	public String getAccountFund() {
		return accountFund;
	}

	public void setAccountFund(String accountFund) {
		this.accountFund = accountFund;
	}

	public String getCis() {
		return cis;
	}

	public void setCis(String cis) {
		this.cis = cis;
	}

	public String getDebitCard() {
		return debitCard;
	}

	public void setDebitCard(String debitCard) {
		this.debitCard = debitCard;
	}

	public String getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}

	public KBankHeaderRequest getKbankHeader() {
		return kbankHeader;
	}

	public void setKbankHeader(KBankHeaderRequest kbankHeader) {
		this.kbankHeader = kbankHeader;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public List<DocumentRequest> getDocuments() {
		return documents;
	}

	public void setDocuments(List<DocumentRequest> documents) {
		this.documents = documents;
	}

	public String getReferDocumentFlag() {
		return referDocumentFlag;
	}

	public void setReferDocumentFlag(String referDocumentFlag) {
		this.referDocumentFlag = referDocumentFlag;
	}

	public String getTransDesc() {
		return transDesc;
	}

	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getTransTypeCode() {
		return transTypeCode;
	}

	public void setTransTypeCode(String transTypeCode) {
		this.transTypeCode = transTypeCode;
	}

	public String getTransTypeDesc() {
		return transTypeDesc;
	}

	public void setTransTypeDesc(String transTypeDesc) {
		this.transTypeDesc = transTypeDesc;
	}

	public String getOtherAcctType() {
		return otherAcctType;
	}

	public void setOtherAcctType(String otherAcctType) {
		this.otherAcctType = otherAcctType;
	}

	public String getOtherAcctNo() {
		return otherAcctNo;
	}

	public void setOtherAcctNo(String otherAcctNo) {
		this.otherAcctNo = otherAcctNo;
	}

}
