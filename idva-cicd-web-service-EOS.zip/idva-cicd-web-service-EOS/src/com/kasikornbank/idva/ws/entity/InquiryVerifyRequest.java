package com.kasikornbank.idva.ws.entity;

import java.util.List;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;

import com.kasikornbank.idva.backend.entity.DocumentRequest;
import com.kasikornbank.idva.backend.entity.ServiceRequest;



@XmlRootElement(name="InquiryVerifyRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType (propOrder={"kbankHeader", "accountNo", "refId","referDocumentFlag","documents", "serviceRequest"})
public class InquiryVerifyRequest {
	@XmlElement(required=true)
	private String accountNo;
	@XmlElement(required=true)
	private String refId;
	private List<DocumentRequest> documents;
	@XmlElement(required=true)
	private String referDocumentFlag;
	@XmlElement(required=true)
	private KBankHeaderRequest kbankHeader;

	private List<ServiceRequest> serviceRequest;

	public KBankHeaderRequest getKbankHeader() {
		return kbankHeader;
	}

	public void setKbankHeader(KBankHeaderRequest kbankHeader) {
		this.kbankHeader = kbankHeader;
	}
	
	public String getReferDocumentFlag() {
		return referDocumentFlag;
	}
	public void setReferDocumentFlag(String referDocumentFlag) {
		this.referDocumentFlag = referDocumentFlag;
	}
	
	public List<DocumentRequest> getDocuments() {
		return documents;
	}
	
	public void setDocuments(List<DocumentRequest> documents) {
		this.documents = documents;
	}
	
	public String getRefId() {
		return refId;
	}
	
	public void setRefId(String refId) {
		this.refId = refId;
	}

	public List<ServiceRequest> getServiceRequest() {
		return serviceRequest;
	}

	public void setServiceRequest(List<ServiceRequest> serviceRequest) {
		this.serviceRequest = serviceRequest;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
}
