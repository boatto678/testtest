package com.kasikornbank.idva.ws.repository.cache;

import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.TimeUnit;

import jakarta.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.cache.concurrent.ConcurrentMapCache;

import com.google.common.cache.CacheBuilder;

public class GuavaCacheFactoryBean implements FactoryBean<ConcurrentMapCache> {

	private static final Logger logger = Logger.getLogger(GuavaCacheFactoryBean.class);
	private String name;
	private int maxSize;
	private int expirationAccessTime;

	private ConcurrentMap<Object, Object> store;
	private ConcurrentMapCache cache;

	@Override
	public ConcurrentMapCache getObject() throws Exception {
		return cache;
	}

	@Override
	public Class<?> getObjectType() {
		return ConcurrentMapCache.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	@PostConstruct
	public void init() {
		logger.info(String.format("Init GuavaCacheFactory[name= %s ,maxSize= %s ,expireAfterAccess= %s minutes]", name, maxSize,
				expirationAccessTime));
		this.store = CacheBuilder.newBuilder().expireAfterAccess(expirationAccessTime, TimeUnit.MINUTES).maximumSize(getMaxSize()).build()
				.asMap();
		this.cache = new ConcurrentMapCache(this.getName(), this.store, true);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	public int getExpirationAccessTime() {
		return expirationAccessTime;
	}

	public void setExpirationAccessTime(int expirationAccessTime) {
		this.expirationAccessTime = expirationAccessTime;
	}

	public ConcurrentMap<Object, Object> getStore() {
		return store;
	}

	public void setStore(ConcurrentMap<Object, Object> store) {
		this.store = store;
	}

	public ConcurrentMapCache getCache() {
		return cache;
	}

	public void setCache(ConcurrentMapCache cache) {
		this.cache = cache;
	}

}