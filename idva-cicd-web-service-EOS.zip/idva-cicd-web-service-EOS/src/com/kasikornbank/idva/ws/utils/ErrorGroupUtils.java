package com.kasikornbank.idva.ws.utils;

import java.util.ArrayList;
import java.util.List;

import com.kasikornbank.idva.backend.entity.DocumentError;
import com.kasikornbank.idva.backend.entity.ErrorGroupResponse;
import com.kasikornbank.idva.core.result.ExecutionResult.Group;

public class ErrorGroupUtils {

public static List<ErrorGroupResponse> getErrorGroups(List<DocumentError> errors, List<Group> groups) {
		
		List<ErrorGroupResponse> groupList = new ArrayList<ErrorGroupResponse>();
		if(null != groups){
			for(Group g : groups){
				List<com.kasikornbank.idva.core.result.ExecutionResult.Error> e = g.getErrors();
				List<DocumentError> errorList = new ArrayList<DocumentError>();
				for(com.kasikornbank.idva.core.result.ExecutionResult.Error error : e){
					DocumentError documentError = new DocumentError();
					documentError.setCode(error.getCode());
					documentError.setDescription(error.getDesc());
					errorList.add(documentError);
				}
				if(errorList.size() > 0){
					ErrorGroupResponse group = new ErrorGroupResponse();
					group.setCode(g.getCode());
					group.setDescription(g.getName());
					group.setErrors(errorList);
					groupList.add(group);
				}
			}
		}
		return groupList;
	}
	
}
