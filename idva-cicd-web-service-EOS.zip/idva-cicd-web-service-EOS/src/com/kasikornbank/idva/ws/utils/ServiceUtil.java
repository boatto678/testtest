package com.kasikornbank.idva.ws.utils;

import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;

import com.kasikornbank.idva.backend.utils.StaticContextHolder;
import com.kasikornbank.idva.dao.IWebServiceLogDao;
import com.kasikornbank.idva.dao.domain.WebServiceLog;
import com.kasikornbank.idva.ws.IDVAWebServiceImpl;
import com.kasikornbank.idva.ws.enums.XmlTypeEnums;

public class ServiceUtil {

	private static final Logger LOGGER = Logger.getLogger(IDVAWebServiceImpl.class);

	private ServiceUtil() {
	}

	public static String generateUID() {
		return "";
	}

	public static void logError(String transactionId, Throwable e) {
		LOGGER.error(String.format("Transaction-ID:%s _{ %s : ", transactionId, e.getMessage()));
		LOGGER.error(e.getMessage(), e);
		LOGGER.error("}_");
	}

	// private final static ExecutorService executorService =
	// Executors.newSingleThreadExecutor();
	private final static ObjectMapper mapper = new ObjectMapper();

	public static void logRequest(final Object request) {
		logRequest(request, null,null);
	}
	
	public static void logRequest(final Object request, final String uuid , final String key) {
		LOGGER.debug("Start logRequest - >");
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		executorService.execute(new Runnable() {
			public void run() {
				try {
					WebServiceLog domain = new WebServiceLog();
					domain.setUuid(uuid);
					domain.setKey(key);
					domain.setXmlType(XmlTypeEnums.REQUEST);
					domain.setTransactionDate(new Date());
					domain.setXml(mapper.writeValueAsString(request));
					saveLog(domain);
				} catch (Exception e) {
					LOGGER.error(e.toString(), e);
				}
			}
		});
		executorService.shutdown();
	}

	public static void logResponse(final Object response) { 
		logResponse(response, null,null);
	}
	
	public static void logResponse(final Object response, final String uuid , final String key) {
		LOGGER.debug("Start logResponse - >");
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		executorService.execute(new Runnable() {
			public void run() {
				try {
					WebServiceLog domain = new WebServiceLog();
					domain.setUuid(uuid);
					domain.setKey(key);
					domain.setXmlType(XmlTypeEnums.RESPONSE);
					domain.setTransactionDate(new Date());
					domain.setXml(mapper.writeValueAsString(response));
					saveLog(domain);
				} catch (Exception e) {
					LOGGER.error(e.toString(), e);
				}
			}
		});
		executorService.shutdown();
	}

	private static synchronized void saveLog(WebServiceLog domain) {
		IWebServiceLogDao webServiceLogDao = null;
		try {
			webServiceLogDao = StaticContextHolder.getBean(IWebServiceLogDao.class);
			webServiceLogDao.save(domain);
		} catch (Exception e) {
			LOGGER.error(e.toString(), e);
		}
	}
}
