package com.kasikornbank.idva.ws.enums;

public enum XmlTypeEnums {

	REQUEST("REQUEST"), RESPONSE("RESPONSE");

	private String code;

	private XmlTypeEnums(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

}
