package com.kasikornbank.idva.ws.enums;

public enum StatusCodeEnums {

	SUCCESS("00"), BUSINESS_ERROR("10"),SYSTEM_ERROR("20") ,WARNING("30") , OVERRIDE("40") ;

	private String code;

	private StatusCodeEnums(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

}
