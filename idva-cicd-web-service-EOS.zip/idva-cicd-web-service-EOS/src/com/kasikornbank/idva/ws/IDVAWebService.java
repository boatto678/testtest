package com.kasikornbank.idva.ws;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebParam.Mode;
import jakarta.jws.WebResult;
import jakarta.jws.WebService;
import jakarta.jws.soap.SOAPBinding;
import jakarta.jws.soap.SOAPBinding.Style;
import jakarta.jws.soap.SOAPBinding.Use;
import jakarta.xml.ws.RequestWrapper;
import jakarta.xml.ws.ResponseWrapper;

import com.kasikornbank.idva.ws.entity.InquiryVerifyByAccountNoResponse;
import com.kasikornbank.idva.ws.entity.InquiryVerifyRequest;
import com.kasikornbank.idva.ws.entity.InquiryVerifyResponse;
import com.kasikornbank.idva.ws.entity.InquiryVerifyWithServicesResponse;
import com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusRequest;
import com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusResponse;

@WebService(targetNamespace = "http://ws.idva.kasikornbank.com/", name = "IDVAWebService")
@SOAPBinding(style = Style.RPC, use = Use.LITERAL)
public interface IDVAWebService {

	@WebMethod(operationName = "InquiryVerify")
	@RequestWrapper(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", className = "com.kasikornbank.idva.ws.entity.InquiryVerifyRequest")
	@ResponseWrapper(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", className = "com.kasikornbank.idva.ws.entity.InquiryVerifyResponse")
	@WebResult(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", name = "InquiryVerifyResponse")
	public InquiryVerifyResponse InquiryVerify(
			@WebParam(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", name = "InquiryVerifyRequest", mode = Mode.IN) InquiryVerifyRequest request);

	@WebMethod(operationName = "InquiryVerifyWithServices")
	@RequestWrapper(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", className = "com.kasikornbank.idva.ws.entity.InquiryVerifyRequest")
	@ResponseWrapper(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", className = "com.kasikornbank.idva.ws.entity.InquiryVerifyWithServicesResponse")
	@WebResult(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", name = "InquiryVerifyWithServicesResponse")
	public InquiryVerifyWithServicesResponse InquiryVerifyWithServices(
			@WebParam(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", name = "InquiryVerifyRequest", mode = Mode.IN) InquiryVerifyRequest request);
	
	@WebMethod(operationName = "InquiryVerifyByAccountNo")
	@RequestWrapper(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", className = "com.kasikornbank.idva.ws.entity.InquiryVerifyRequest")
	@ResponseWrapper(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", className = "com.kasikornbank.idva.ws.entity.InquiryVerifyByAccountNoResponse")
	@WebResult(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", name = "InquiryVerifyByAccountNoResponse")
	public InquiryVerifyByAccountNoResponse InquiryVerifyByAccountNo(
			@WebParam(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", name = "InquiryVerifyRequest", mode = Mode.IN) InquiryVerifyRequest request);
	
	@WebMethod(operationName = "InvalidateVerifyStatus")
	@RequestWrapper(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", className = "com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusRequest")
	@ResponseWrapper(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", className = "com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusResponse")
	@WebResult(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", name = "InvalidateVerifyStatusResponse")
	public InvalidateVerifyStatusResponse InvalidateVerifyStatus(
			@WebParam(targetNamespace = "http://ws.idva.kasikornbank.com/ws/types", name = "InvalidateVerifyStatusRequest", mode = Mode.IN) InvalidateVerifyStatusRequest request);
	
}