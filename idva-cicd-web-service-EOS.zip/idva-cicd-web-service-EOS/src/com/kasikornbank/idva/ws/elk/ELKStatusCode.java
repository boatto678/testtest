package com.kasikornbank.idva.ws.elk;

public enum ELKStatusCode {

	SUCCESS("SUCCESS"), FAIL("FAIL"), INVALID_PARAMETER("INVALID_PARAMETER");

	private String code;

	private ELKStatusCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}

}
