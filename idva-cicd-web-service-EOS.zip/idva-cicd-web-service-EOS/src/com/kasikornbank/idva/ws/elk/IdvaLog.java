package com.kasikornbank.idva.ws.elk;

import org.apache.commons.lang3.StringUtils;

public class IdvaLog {
	String funcNum;
	String rqUid;
	String rqDate;
	String rqAppId;
	String refId;
	String response;
	
	public IdvaLog(
			String funcNum,
			String rqUid,
			String rqDate,
			String rqAppId,
			String refId,
			String response) {
		
		this.funcNum = funcNum;
		this.rqUid = rqUid;
		this.rqDate = rqDate;
		this.rqAppId = rqAppId;
		this.refId = refId;
		this.response = response;
	}


	public String getFuncNum() {
		return funcNum;
	}


	public void setFuncNum(String funcNum) {
		this.funcNum = funcNum;
	}


	public String getRqUid() {
		return rqUid;
	}


	public void setRqUid(String rqUid) {
		this.rqUid = rqUid;
	}


	public String getRqDate() {
		return rqDate;
	}


	public void setRqDate(String rqDate) {
		this.rqDate = rqDate;
	}


	public String getRqAppId() {
		return rqAppId;
	}


	public void setRqAppId(String rqAppId) {
		this.rqAppId = rqAppId;
	}


	public String getRefId() {
		return refId;
	}


	public void setRefId(String refId) {
		this.refId = refId;
	}


	public String getResponse() {
		return response;
	}


	public void setResponse(String response) {
		this.response = response;
	}

	
}
