package com.kasikornbank.idva.dao.domain;

import java.util.Date;

import com.kasikornbank.idva.ws.enums.XmlTypeEnums;

public class WebServiceLog {
	private int id;
	private String uuid;
	private String key;
	private String xml;
	private XmlTypeEnums xmlType;
	private Date transactionDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getXml() {
		return xml;
	}

	public void setXml(String xml) {
		this.xml = xml;
	}

	public XmlTypeEnums getXmlType() {
		return xmlType;
	}

	public void setXmlType(XmlTypeEnums xmlType) {
		this.xmlType = xmlType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

}
