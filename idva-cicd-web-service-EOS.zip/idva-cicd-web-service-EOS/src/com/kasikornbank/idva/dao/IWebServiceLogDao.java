package com.kasikornbank.idva.dao;

import com.kasikornbank.idva.dao.domain.WebServiceLog;

public interface IWebServiceLogDao {
	public boolean save(WebServiceLog webServiceLog);
}
