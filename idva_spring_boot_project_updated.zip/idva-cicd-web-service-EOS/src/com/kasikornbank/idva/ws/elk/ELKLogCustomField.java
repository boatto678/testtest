package com.kasikornbank.idva.ws.elk;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import org.apache.logging.log4j.ThreadContext;

public class ELKLogCustomField {
	private static final Marker ELK_MK = MarkerManager.getMarker("ELK");	
	
	public static void elkLogInfo(Logger ELKLOG , IdvaLog idvaLog ) {
		
		if(idvaLog == null) {
			return;
		}		
		
			ThreadContext.put("kbtg.funcNum", idvaLog.getFuncNum());
			ThreadContext.put("kbtg.rqUid", idvaLog.getRqUid());
			ThreadContext.put("kbtg.rqDate", idvaLog.getRqDate());
			ThreadContext.put("kbtg.rqAppId", idvaLog.getRqAppId());
			ThreadContext.put("kbtg.refId", idvaLog.getRefId());
			ThreadContext.put("kbtg.response", idvaLog.getResponse());			
			ELKLOG.info(ELK_MK, "");
			ThreadContext.clearAll();
		
	}

	public static void logError(Logger ELKLOG , IdvaLog idvaLog , Exception ex) {
		ThreadContext.put("kbtg.funcNum", idvaLog.getFuncNum());
		ThreadContext.put("kbtg.rqUid", idvaLog.getRqUid());
		ThreadContext.put("kbtg.rqDate", idvaLog.getRqDate());
		ThreadContext.put("kbtg.rqAppId", idvaLog.getRqAppId());
		ThreadContext.put("kbtg.refId", idvaLog.getRefId());
		ThreadContext.put("kbtg.response", idvaLog.getResponse());
		ELKLOG.error(ELK_MK, ex.getMessage());
		ThreadContext.clearAll();
	}
}
