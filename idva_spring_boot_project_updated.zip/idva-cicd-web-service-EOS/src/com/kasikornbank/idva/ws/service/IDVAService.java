package com.kasikornbank.idva.ws.service;

import com.kasikornbank.idva.ws.entity.InquiryVerifyByAccountNoResponse;
import com.kasikornbank.idva.ws.entity.InquiryVerifyRequest;
import com.kasikornbank.idva.ws.entity.InquiryVerifyResponse;
import com.kasikornbank.idva.ws.entity.InquiryVerifyWithServicesResponse;
import com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusRequest;
import com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusResponse;
import com.kasikornbank.idva.ws.excaption.IDVAException;

public interface IDVAService {

	public InquiryVerifyResponse inquiryVerify(InquiryVerifyRequest request)throws IDVAException ;
	
	public InquiryVerifyWithServicesResponse inquiryVerifyWithServices(InquiryVerifyRequest request)throws IDVAException ;
	
	public InquiryVerifyByAccountNoResponse inquiryVerifyByAccountNo(InquiryVerifyRequest request)throws IDVAException ;
	
	public InvalidateVerifyStatusResponse invalidateVerifyStatus(InvalidateVerifyStatusRequest request)  throws IDVAException ;

}
