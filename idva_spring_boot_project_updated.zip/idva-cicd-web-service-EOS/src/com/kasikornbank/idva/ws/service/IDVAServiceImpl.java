package com.kasikornbank.idva.ws.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

import com.kasikornbank.idva.backend.dao.InvalidateTransactionStatusDao;
import com.kasikornbank.idva.backend.dao.SpecialRefVerifyDao;
import com.kasikornbank.idva.backend.dao.VerifyTransactionByAccountDao;
import com.kasikornbank.idva.backend.dao.VerifyTransactionDao;
import com.kasikornbank.idva.backend.entity.AdditionalDocument;
import com.kasikornbank.idva.backend.entity.DocumentError;
import com.kasikornbank.idva.backend.entity.DocumentRequest;
import com.kasikornbank.idva.backend.entity.DocumentResponse;
import com.kasikornbank.idva.backend.entity.DocumentServiceResponse;
import com.kasikornbank.idva.backend.entity.DocumentValidateStatus;
import com.kasikornbank.idva.backend.entity.ErrorGroupResponse;
import com.kasikornbank.idva.backend.entity.InvalidateTransactionItemStatus;
import com.kasikornbank.idva.backend.entity.InvalidateTransactionStatus;
import com.kasikornbank.idva.backend.entity.SereviceResponse;
import com.kasikornbank.idva.backend.entity.ServiceRequest;
import com.kasikornbank.idva.backend.entity.SpecialRefVerify;
import com.kasikornbank.idva.backend.entity.VerifyTransaction;
import com.kasikornbank.idva.backend.entity.VerifyTransactionByAccount;
import com.kasikornbank.idva.backend.entity.VerifyTransactionCode;
import com.kasikornbank.idva.backend.entity.VerifyTransactionItem;
import com.kasikornbank.idva.backend.entity.VerifyTransactionItemExtend;
import com.kasikornbank.idva.backend.entity.VerifyTransactionItemStatus;
import com.kasikornbank.idva.backend.enums.ReadFromCard;
import com.kasikornbank.idva.backend.enums.RecordStatus;
import com.kasikornbank.idva.backend.enums.ReferDocFlag;
import com.kasikornbank.idva.backend.enums.StatusWS;
import com.kasikornbank.idva.backend.service.InvalidateTransactionStatusService;
import com.kasikornbank.idva.backend.utils.ValidateUtil;
import com.kasikornbank.idva.core.IDVAVerifyCore;
import com.kasikornbank.idva.core.enums.Status;
import com.kasikornbank.idva.core.result.ExecutionResult;
import com.kasikornbank.idva.core.result.ExecutionResult.Rule;
import com.kasikornbank.idva.ws.entity.InquiryVerifyByAccountNoResponse;
import com.kasikornbank.idva.ws.entity.InquiryVerifyRequest;
import com.kasikornbank.idva.ws.entity.InquiryVerifyResponse;
import com.kasikornbank.idva.ws.entity.InquiryVerifyWithServicesResponse;
import com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusRequest;
import com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusResponse;
import com.kasikornbank.idva.ws.enums.StatusCodeEnums;
import com.kasikornbank.idva.ws.excaption.IDVAException;
import com.kasikornbank.idva.ws.utils.ApplicationConfig;
import com.kasikornbank.idva.ws.utils.ErrorGroupUtils;



@Service("IDVAService")
@Scope(value = "singleton", proxyMode = ScopedProxyMode.TARGET_CLASS)
class IDVAServiceImpl implements IDVAService {
	
	@Autowired
	VerifyTransactionDao verifyTransactionDao;
	
	@Autowired
	VerifyTransactionByAccountDao verifyTransactionByAccountDao;
	
	@Autowired
	InvalidateTransactionStatusDao invalidateTransactionStatusDao;
	
	@Autowired
	InvalidateTransactionStatusService invalidateTransactionStatusService;
	
	@Autowired
	SpecialRefVerifyDao specialRefVerifyDao;
	
	private static final Logger LOGGER = Logger.getLogger(IDVAServiceImpl.class);
	
	private static IDVAVerifyCore core =  IDVAVerifyCore.getInstance();
	
	private static int SERVICE_OLD_OPEN_ACC_ID = 1;
	private static int SERVICE_NEW_OPEN_ACC_ID = 2;
	private static int SERVICE_NDID_ID = 3;
	
	private static String OLD_OPEN_ACC_MENU_ID = "01";
	private static String NEW_OPEN_ACC_MENU_ID = "02";
	private static String NDID_MENU_ID = "03";
	
	private void validateRefID(String refId) throws IDVAException {
		Boolean hasRefID = false;
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refId);
		hasRefID = verifyTransactionDao.chkRefIdStatus(refId, RecordStatus.ACTIVE.name());
		if (!hasRefID) {
			LOGGER.info(String.format(ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID") + " %s", refId));
			throw new IDVAException("1001", ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID"));
		}
	}
	
	private void setItemExtend(VerifyTransactionItem item, DocumentResponse documentResponse){
		VerifyTransactionItemExtend itemExtend = item.getVerifyTransactionItemExtend();
				documentResponse.setTitleTh(itemExtend.getTitleTh());
				documentResponse.setTitleEn(itemExtend.getTitleEn());
				documentResponse.setNameEn(itemExtend.getNameEn());
				documentResponse.setMiddleNameTh(itemExtend.getMidName());
				documentResponse.setMiddleNameEn(itemExtend.getMidNameEn());
				documentResponse.setLastNameEn(itemExtend.getLstNameEn());
				documentResponse.setSex(itemExtend.getSex());
				documentResponse.setIssueDate(ValidateUtil.formateThToUs(itemExtend.getIssueDate()));
				documentResponse.setIssuePlace(itemExtend.getIssuePlace());
				documentResponse.setIssueAgency(itemExtend.getIssueAgency());
				documentResponse.setHouseNo(StringUtils.isEmpty(itemExtend.getHouseNo()) ? "" : itemExtend.getHouseNo().length() <= 15 ? itemExtend.getHouseNo() : itemExtend.getHouseNo().substring(0, 15));
				documentResponse.setVillageNo(itemExtend.getVillageNo());
				documentResponse.setAlley(itemExtend.getAlley());
				documentResponse.setLane(itemExtend.getLane());
				documentResponse.setRoad(itemExtend.getRoad());
				documentResponse.setTambol(itemExtend.getTambol());
				documentResponse.setAmphur(itemExtend.getAmphur());
				documentResponse.setProvince(itemExtend.getProvince());
				documentResponse.setAddressLine(itemExtend.getAddressLine());
//				documentResponse.setLaserNo("");
//				documentResponse.setCid("");
//				documentResponse.setCardNumber("");
	}
	
	private void inquiryVerifyDocFlagYes(InquiryVerifyRequest request , InquiryVerifyResponse response ) throws IDVAException{
		String refID = request.getRefId();
		validateRefID(refID);		
		List<DocumentResponse> documentResponses = new ArrayList<DocumentResponse>();
		List<DocumentRequest> rqDocs = request.getDocuments();
		Integer totalItemsInRef = verifyTransactionDao.countItemsByRefId(refID,RecordStatus.ACTIVE.name());
		int numberOfRefID = totalItemsInRef;
		int numberOfValid = 0;
		int numberOfInValid = 0;
		for(DocumentRequest documentRequest : rqDocs){
			if(documentRequest == null){
				continue;
			}
			String rqDocId = StringUtils.trimToEmpty(documentRequest.getDocumentId());
			String rqDocType = StringUtils.trimToEmpty(documentRequest.getDocumentType());
			Boolean isExist = false;
			Boolean isMissingManField = (StringUtils.isEmpty(rqDocId) || StringUtils.isEmpty(rqDocType)) ||
					(StringUtils.isEmpty(rqDocId) && StringUtils.isEmpty(rqDocType));
			
			if(isMissingManField){
				DocumentResponse documentResponse = new DocumentResponse();
				documentResponse.setDocumentId(rqDocId);
				documentResponse.setDocumentType(rqDocType);
				List<DocumentError> errors = new ArrayList<DocumentError>();
				DocumentError docError = new DocumentError();
				docError.setCode(DocumentValidateStatus.ERROR_MISSING_MANDATORY_FIELD);
				docError.setDescription(ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"));
				errors.add(docError);
				documentResponse.setErrors(errors);
				documentResponse.setStatus(StatusWS.RED.getCode());
				documentResponses.add(documentResponse);
				numberOfInValid++;	
				continue;
			}
			VerifyTransactionItem verifytransactionItem = verifyTransactionDao.getItemsByDocIdAndDocType(refID ,rqDocId, rqDocType);
			if( (verifytransactionItem != null) &&  ( rqDocId.equals(verifytransactionItem.getDocId()) | rqDocId.equals(verifytransactionItem.getSrcDocId()) )
					&& rqDocType.equals(verifytransactionItem.getDocumentType().getDocumentTypeId().toString())){
				String expireDate = verifytransactionItem.getCardExp();
				DocumentResponse documentResponse = new DocumentResponse();
				documentResponse.setDocumentType((verifytransactionItem.getDocumentType().getDocumentTypeId() == null) 
						? "":verifytransactionItem.getDocumentType().getDocumentTypeId().toString());
				documentResponse.setDocumentId( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId())
						: StringUtils.trimToEmpty(verifytransactionItem.getDocId()));
				documentResponse.setDateOfBirth( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDob()).equals("")) ? StringUtils.trimToEmpty(verifytransactionItem.getSrcDob())
						: StringUtils.trimToEmpty(verifytransactionItem.getDob()));
				documentResponse.setDateOfBirth(ValidateUtil.formateThToUs(documentResponse.getDateOfBirth()));
				documentResponse.setName( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcName()).equals(""))? StringUtils.trimToEmpty(verifytransactionItem.getSrcName())
						: StringUtils.trimToEmpty(verifytransactionItem.getName()));
				documentResponse.setSurename( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName())
						: StringUtils.trimToEmpty(verifytransactionItem.getLstName()));
				documentResponse.setChannel( (ReadFromCard.YES == verifytransactionItem.getReadFromCard())? ReadFromCard.YES.getDesc() :  ReadFromCard.NO.getDesc());
				documentResponse.setExpireDate(ValidateUtil.formateThToUs(expireDate));
				documentResponse.setNatCode( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode()).equals("") )?StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode())
						:StringUtils.trimToEmpty(verifytransactionItem.getNationCode()));
				
				if(null != verifytransactionItem.getVerifyTransactionItemExtend()){
					setItemExtend(verifytransactionItem, documentResponse);
				}
				
				List<VerifyTransactionItemStatus> itemsStatus = verifytransactionItem.getVerifyTransactionItemStatus();
				List<DocumentError> errors = new ArrayList<DocumentError>();
				for(VerifyTransactionItemStatus itemStatus : itemsStatus){
					DocumentError docError = new DocumentError();
					docError.setCode(itemStatus.getDocumentValidateStatus().getCode());
					docError.setDescription(itemStatus.getDocumentValidateStatus().getDesc());
					errors.add(docError);
				}
				if( ValidateUtil.chkExpireDate(documentResponse.getExpireDate()) ){
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
					errors.add(docError);
					VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
					DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
					documentValidateStatus.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
					documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
					verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
					verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
				}	
				Boolean isUsed = invalidateTransactionStatusDao.isRefIdAndDocIdAndDocTypeExists(refID , rqDocId , rqDocType);
				if(isUsed){
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
					errors.add(docError);
					VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
					DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
					documentValidateStatus.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
					documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
					verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
					verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
				}
				if( errors.size() == 0 ){
					numberOfValid++;
				}else if (errors.size() > 0){	
					numberOfInValid++;
				}
				documentResponse.setStatus(StringUtils.trimToEmpty(verifytransactionItem.getDisplayStatus().getCode()));
				documentResponse.setErrors(errors);
				documentResponses.add(documentResponse);
				continue;
			}
			if(!isExist){
				DocumentResponse documentResponse = new DocumentResponse();
				documentResponse.setDocumentId(rqDocId);
				documentResponse.setDocumentType(rqDocType);
				List<DocumentError> errors = new ArrayList<DocumentError>();
				DocumentError docError = new DocumentError();
				docError.setCode(DocumentValidateStatus.ERROR_NOT_FOUND_REF_ID_DOC_ID);
				docError.setDescription(ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID_DOC_ID"));
				errors.add(docError);
				documentResponse.setErrors(errors);
				documentResponse.setStatus(StatusWS.RED.getCode());
				documentResponses.add(documentResponse);
				numberOfInValid++;		
			}
		}
		response.setNumberOfValid(numberOfValid);
		response.setNumberOfInValid(numberOfInValid);
		response.setNumberOfRefId(numberOfRefID);
		response.setDocuments(documentResponses);
		List<DocumentResponse> chkResponseStatus = response.getDocuments();	
		String statusWS = StatusWS.GREEN.getCode();
		Boolean chkGray = false;
		for(DocumentResponse rs : chkResponseStatus){
			if(StatusWS.RED.getCode().equals(rs.getStatus())){
				statusWS = StatusWS.RED.getCode();
				break;
			}
			if(StatusWS.GRAY.getCode().equals(rs.getStatus())){
				statusWS = StatusWS.GRAY.getCode();
				chkGray = true;
			}
		}
		if(!StatusWS.RED.getCode().equals(statusWS) && chkGray){
			statusWS = StatusWS.GRAY.getCode();
		} 
		//String statusWS = chkResponseStatus.stream().filter(i -> StringUtils.isNotEmpty(i.getStatus())).map(DocumentResponse::getStatus).max(Comparator.comparing(Integer::parseInt)).get();	
		response.setStatus(statusWS);
		response.setReferDocumentFlag(ReferDocFlag.YES.getCode());
	}
	
	private void inquiryVerifyWithServicesDocFlagYes(InquiryVerifyRequest request , InquiryVerifyWithServicesResponse response ) throws IDVAException{
		String refID = request.getRefId();
		validateRefID(refID);		
		List<DocumentServiceResponse> documents = new ArrayList<DocumentServiceResponse>();
		List<SereviceResponse> serviceResponses = new ArrayList<SereviceResponse>();
		List<DocumentRequest> rqDocs = request.getDocuments();
		List<ServiceRequest> serviceRequest = request.getServiceRequest();
		
		Integer totalItemsInRef = verifyTransactionDao.countItemsByRefId(refID,RecordStatus.ACTIVE.name());
		int numberOfRefID = totalItemsInRef;
		int numberOfValid = 0;
		int numberOfInValid = 0;

		for(DocumentRequest documentRequest : rqDocs){
			if(documentRequest == null){
				continue;
			}
			String rqDocId = StringUtils.trimToEmpty(documentRequest.getDocumentId());
			String rqDocType = StringUtils.trimToEmpty(documentRequest.getDocumentType());
			Boolean isMissingManField = (StringUtils.isEmpty(rqDocId) || StringUtils.isEmpty(rqDocType)) ||
					(StringUtils.isEmpty(rqDocId) && StringUtils.isEmpty(rqDocType));
			
			if(isMissingManField){
				continue;
			}
			
			VerifyTransactionItem verifytransactionItem = verifyTransactionDao.getItemsByDocIdAndDocType(refID ,rqDocId, rqDocType);
			if( (verifytransactionItem != null) &&  ( rqDocId.equals(verifytransactionItem.getDocId()) | rqDocId.equals(verifytransactionItem.getSrcDocId()) )
					&& rqDocType.equals(verifytransactionItem.getDocumentType().getDocumentTypeId().toString())){
				DocumentServiceResponse documentResponse = new DocumentServiceResponse();
				String expireDate = verifytransactionItem.getCardExp();
				AdditionalDocument additionalDocument = verifytransactionItem.getAdditionalDocument();
				documentResponse.setType((verifytransactionItem.getDocumentType().getDocumentTypeId() == null) 
						? "":verifytransactionItem.getDocumentType().getDocumentTypeId().toString());
				documentResponse.setId( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId())
						: StringUtils.trimToEmpty(verifytransactionItem.getDocId()));
				documentResponse.setDateOfBirth( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDob()).equals("")) ? StringUtils.trimToEmpty(verifytransactionItem.getSrcDob())
						: StringUtils.trimToEmpty(verifytransactionItem.getDob()));
				documentResponse.setDateOfBirth(ValidateUtil.formateThToUs(documentResponse.getDateOfBirth()));
				documentResponse.setName( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcName()).equals(""))? StringUtils.trimToEmpty(verifytransactionItem.getSrcName())
						: StringUtils.trimToEmpty(verifytransactionItem.getName()));
				documentResponse.setSurname( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName())
						: StringUtils.trimToEmpty(verifytransactionItem.getLstName()));
				documentResponse.setChannel( (ReadFromCard.YES == verifytransactionItem.getReadFromCard())? ReadFromCard.YES.getDesc() :  ReadFromCard.NO.getDesc());
				documentResponse.setExpireDate(ValidateUtil.formateThToUs(expireDate));
				documentResponse.setNatCode( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode()).equals("") )?StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode())
						:StringUtils.trimToEmpty(verifytransactionItem.getNationCode()));
				if(null != additionalDocument){
					documentResponse.setAttachDocCode((StringUtils.trimToEmpty(additionalDocument.getCode()).equals("") )?"":StringUtils.trimToEmpty(additionalDocument.getCode()));
					documentResponse.setAttachDocDesc((StringUtils.trimToEmpty(additionalDocument.getDesc()).equals("") )?"":StringUtils.trimToEmpty(additionalDocument.getDesc()));
				}
				
				documents.add(documentResponse);
			}
		}
		
		for(ServiceRequest svRq : serviceRequest) {
			
			SereviceResponse serviceResponse = new SereviceResponse();
			List<DocumentServiceResponse> documentServiceList = new ArrayList<DocumentServiceResponse>();
			
			for(DocumentRequest documentRequest : rqDocs){
				String rqDocId = StringUtils.trimToEmpty(documentRequest.getDocumentId());
				String rqDocType = StringUtils.trimToEmpty(documentRequest.getDocumentType());
				Boolean isMissingManField = (StringUtils.isEmpty(rqDocId) || StringUtils.isEmpty(rqDocType)) ||
						(StringUtils.isEmpty(rqDocId) && StringUtils.isEmpty(rqDocType));
				DocumentServiceResponse document = new DocumentServiceResponse();
				List<ErrorGroupResponse> errorGroupList = new ArrayList<ErrorGroupResponse>();
				if(isMissingManField){
					
					ErrorGroupResponse errorGroup = new ErrorGroupResponse();
					List<DocumentError> errors = new ArrayList<DocumentError>();
					
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_MISSING_MANDATORY_FIELD);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"));
					errors.add(docError);
					
					errorGroup.setCode("99");
					errorGroup.setDescription("Red");
					errorGroup.setErrors(errors);
					errorGroupList.add(errorGroup);
					
					document.setId(rqDocId);
					document.setStatus(StatusWS.RED.getCode());
					document.setErrorGroups(errorGroupList);
					
					documentServiceList.add(document);
					continue;
				}
				
				VerifyTransactionItem verifytransactionItem = verifyTransactionDao.getItemsByDocIdAndDocType(refID ,rqDocId, rqDocType);
				if( (verifytransactionItem != null) &&  ( rqDocId.equals(verifytransactionItem.getDocId()) | rqDocId.equals(verifytransactionItem.getSrcDocId()) )
						&& rqDocType.equals(verifytransactionItem.getDocumentType().getDocumentTypeId().toString())){
					
					List<VerifyTransactionItemStatus> itemsStatus = verifytransactionItem.getVerifyTransactionItemStatus();
					List<DocumentError> errors = new ArrayList<DocumentError>();
					
					for(VerifyTransactionItemStatus itemStatus : itemsStatus){
						DocumentError docError = new DocumentError();
						docError.setCode(itemStatus.getDocumentValidateStatus().getCode());
						docError.setDescription(itemStatus.getDocumentValidateStatus().getDesc());
						errors.add(docError);
					}
					
					ErrorGroupResponse redGroup = new ErrorGroupResponse();
					redGroup.setCode("99");
					redGroup.setDescription("Red");
					
					if(ValidateUtil.chkExpireDate(document.getExpireDate())){
						DocumentError docError = new DocumentError();
						docError.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
						docError.setDescription(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
						errors.add(docError);
						VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
						DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
						documentValidateStatus.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
						documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
						verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
						verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
					}
					
					Boolean isUsed = invalidateTransactionStatusDao.isRefIdAndDocIdAndDocTypeExists(refID , rqDocId , rqDocType);
					if(isUsed){
						DocumentError docError = new DocumentError();
						docError.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
						docError.setDescription(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
						errors.add(docError);
						VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
						DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
						documentValidateStatus.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
						documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
						verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
						verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
					}
					
					String statusOldRule = StringUtils.trimToEmpty(verifytransactionItem.getDisplayStatus().getCode());
					String status = StatusWS.GREEN.getCode();
					List<String> errorList = new ArrayList<String>();
					for (DocumentError error : errors) {
						errorList.add(error.getCode());
					}
					String[] arrayErrors = new String[errorList.size()];
					arrayErrors = errorList.toArray(arrayErrors);
					if(OLD_OPEN_ACC_MENU_ID.equals(svRq.getCode())){
						status = statusOldRule;
						int[] services = { SERVICE_OLD_OPEN_ACC_ID };
						ExecutionResult results = core.execute(services, arrayErrors);
						errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
					} else
					if(NEW_OPEN_ACC_MENU_ID.equals(svRq.getCode())){
						int[] services = { SERVICE_NEW_OPEN_ACC_ID };
						ExecutionResult results = core.execute(services, arrayErrors);
						Rule rule = results.getRules().get(0);
						for (com.kasikornbank.idva.core.result.ExecutionResult.Service service : rule.getServices()) {
							if(SERVICE_NEW_OPEN_ACC_ID == service.getId()){
								if(Status.RED.equals(service.getStatus())){
									status = StatusWS.RED.getCode();
								} else 
								if(Status.GRAY.equals(service.getStatus())){
									status = StatusWS.GRAY.getCode();
								}
							}
						}
						if("03".equals(statusOldRule)){
							status = statusOldRule;
						}
						errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
					} else 
					if(NDID_MENU_ID.equals(svRq.getCode())){
						int[] services = { SERVICE_NDID_ID };
						ExecutionResult results = core.execute(services, arrayErrors);
						Rule rule = results.getRules().get(0);
						for (com.kasikornbank.idva.core.result.ExecutionResult.Service service : rule.getServices()) {
							if(SERVICE_NDID_ID == service.getId()){
								if(Status.RED.equals(service.getStatus())){
									status = StatusWS.RED.getCode();
								} else 
								if(Status.GRAY.equals(service.getStatus())){
									status = StatusWS.GRAY.getCode();
								}
							}
						}
						if("03".equals(statusOldRule)){
							status = statusOldRule;
						}
						errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
					}
					
					document.setId(rqDocId);
					document.setStatus(status);
					document.setErrorGroups(errorGroupList);
					documentServiceList.add(document);
				}
				else {
					ErrorGroupResponse errorGroup = new ErrorGroupResponse();
					List<DocumentError> errors = new ArrayList<DocumentError>();
					
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_NOT_FOUND_REF_ID_DOC_ID);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID_DOC_ID"));
					errors.add(docError);
					
					errorGroup.setCode("99");
					errorGroup.setDescription("Red");
					errorGroup.setErrors(errors);
					errorGroupList.add(errorGroup);
					
					document.setId(rqDocId);
					document.setStatus(StatusWS.RED.getCode());
					document.setErrorGroups(errorGroupList);
					documentServiceList.add(document);
				}
				
			}
			
			List<DocumentServiceResponse> chkResponseStatus = documentServiceList;	
			String statusWS = StatusWS.GREEN.getCode();
			Boolean chkGray = false;
			for(DocumentServiceResponse rs : chkResponseStatus){
				if(StatusWS.RED.getCode().equals(rs.getStatus())){
					statusWS = StatusWS.RED.getCode();
					break;
				}
				if(StatusWS.GRAY.getCode().equals(rs.getStatus())){
					statusWS = StatusWS.GRAY.getCode();
					chkGray = true;
				}
			}
			if(!StatusWS.RED.getCode().equals(statusWS) && chkGray){
				statusWS = StatusWS.GRAY.getCode();
			} 
			
			serviceResponse.setStatus(statusWS);
			serviceResponse.setCode(svRq.getCode());
			serviceResponse.setDescription(getServiceDescription(svRq.getCode()));
			serviceResponse.setDocumentServices(documentServiceList);
			serviceResponses.add(serviceResponse);
		}
		
		
		response.setNumberOfValid(numberOfValid);
		response.setNumberOfInValid(numberOfInValid);
		response.setNumberOfRefId(numberOfRefID);
		response.setDocuments(documents);
		response.setServices(serviceResponses);
		response.setReferDocumentFlag(ReferDocFlag.YES.getCode());
	}
	
	private void inquiryVerifyByAccountNoDocFlagYes(String refID, InquiryVerifyRequest request , InquiryVerifyByAccountNoResponse response ) throws IDVAException{
		validateRefID(refID);		
		List<DocumentServiceResponse> documents = new ArrayList<DocumentServiceResponse>();
		List<SereviceResponse> serviceResponses = new ArrayList<SereviceResponse>();
		List<DocumentRequest> rqDocs = request.getDocuments();
		List<ServiceRequest> serviceRequest = request.getServiceRequest();
		
		Integer totalItemsInRef = verifyTransactionDao.countItemsByRefId(refID,RecordStatus.ACTIVE.name());
		int numberOfRefID = totalItemsInRef;
		int numberOfValid = 0;
		int numberOfInValid = 0;

		for(DocumentRequest documentRequest : rqDocs){
			if(documentRequest == null){
				continue;
			}
			String rqDocId = StringUtils.trimToEmpty(documentRequest.getDocumentId());
			String rqDocType = StringUtils.trimToEmpty(documentRequest.getDocumentType());
			Boolean isMissingManField = (StringUtils.isEmpty(rqDocId) || StringUtils.isEmpty(rqDocType)) ||
					(StringUtils.isEmpty(rqDocId) && StringUtils.isEmpty(rqDocType));
			
			if(isMissingManField){
				continue;
			}
			
			VerifyTransactionItem verifytransactionItem = verifyTransactionDao.getItemsByDocIdAndDocType(refID ,rqDocId, rqDocType);
			if( (verifytransactionItem != null) &&  ( rqDocId.equals(verifytransactionItem.getDocId()) | rqDocId.equals(verifytransactionItem.getSrcDocId()) )
					&& rqDocType.equals(verifytransactionItem.getDocumentType().getDocumentTypeId().toString())){
				DocumentServiceResponse documentResponse = new DocumentServiceResponse();
				String expireDate = verifytransactionItem.getCardExp();
				AdditionalDocument additionalDocument = verifytransactionItem.getAdditionalDocument();
				documentResponse.setType((verifytransactionItem.getDocumentType().getDocumentTypeId() == null) 
						? "":verifytransactionItem.getDocumentType().getDocumentTypeId().toString());
				documentResponse.setId( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId())
						: StringUtils.trimToEmpty(verifytransactionItem.getDocId()));
				documentResponse.setDateOfBirth( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDob()).equals("")) ? StringUtils.trimToEmpty(verifytransactionItem.getSrcDob())
						: StringUtils.trimToEmpty(verifytransactionItem.getDob()));
				documentResponse.setDateOfBirth(ValidateUtil.formateThToUs(documentResponse.getDateOfBirth()));
				documentResponse.setName( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcName()).equals(""))? StringUtils.trimToEmpty(verifytransactionItem.getSrcName())
						: StringUtils.trimToEmpty(verifytransactionItem.getName()));
				documentResponse.setSurname( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName())
						: StringUtils.trimToEmpty(verifytransactionItem.getLstName()));
				documentResponse.setChannel( (ReadFromCard.YES == verifytransactionItem.getReadFromCard())? ReadFromCard.YES.getDesc() :  ReadFromCard.NO.getDesc());
				documentResponse.setExpireDate(ValidateUtil.formateThToUs(expireDate));
				documentResponse.setNatCode( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode()).equals("") )?StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode())
						:StringUtils.trimToEmpty(verifytransactionItem.getNationCode()));
				if(null != additionalDocument){
					documentResponse.setAttachDocCode((StringUtils.trimToEmpty(additionalDocument.getCode()).equals("") )?"":StringUtils.trimToEmpty(additionalDocument.getCode()));
					documentResponse.setAttachDocDesc((StringUtils.trimToEmpty(additionalDocument.getDesc()).equals("") )?"":StringUtils.trimToEmpty(additionalDocument.getDesc()));
				}
				
				documents.add(documentResponse);
			}
		}
		
		for(ServiceRequest svRq : serviceRequest) {
			
			SereviceResponse serviceResponse = new SereviceResponse();
			List<DocumentServiceResponse> documentServiceList = new ArrayList<DocumentServiceResponse>();
			
			for(DocumentRequest documentRequest : rqDocs){
				String rqDocId = StringUtils.trimToEmpty(documentRequest.getDocumentId());
				String rqDocType = StringUtils.trimToEmpty(documentRequest.getDocumentType());
				Boolean isMissingManField = (StringUtils.isEmpty(rqDocId) || StringUtils.isEmpty(rqDocType)) ||
						(StringUtils.isEmpty(rqDocId) && StringUtils.isEmpty(rqDocType));
				DocumentServiceResponse document = new DocumentServiceResponse();
				List<ErrorGroupResponse> errorGroupList = new ArrayList<ErrorGroupResponse>();
				if(isMissingManField){
					
					ErrorGroupResponse errorGroup = new ErrorGroupResponse();
					List<DocumentError> errors = new ArrayList<DocumentError>();
					
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_MISSING_MANDATORY_FIELD);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"));
					errors.add(docError);
					
					errorGroup.setCode("99");
					errorGroup.setDescription("Red");
					errorGroup.setErrors(errors);
					errorGroupList.add(errorGroup);
					
					document.setId(rqDocId);
					document.setStatus(StatusWS.RED.getCode());
					document.setErrorGroups(errorGroupList);
					
					documentServiceList.add(document);
					continue;
				}
				
				VerifyTransactionItem verifytransactionItem = verifyTransactionDao.getItemsByDocIdAndDocType(refID ,rqDocId, rqDocType);
				if( (verifytransactionItem != null) &&  ( rqDocId.equals(verifytransactionItem.getDocId()) | rqDocId.equals(verifytransactionItem.getSrcDocId()) )
						&& rqDocType.equals(verifytransactionItem.getDocumentType().getDocumentTypeId().toString())){
					
					List<VerifyTransactionItemStatus> itemsStatus = verifytransactionItem.getVerifyTransactionItemStatus();
					List<DocumentError> errors = new ArrayList<DocumentError>();
					
					for(VerifyTransactionItemStatus itemStatus : itemsStatus){
						DocumentError docError = new DocumentError();
						docError.setCode(itemStatus.getDocumentValidateStatus().getCode());
						docError.setDescription(itemStatus.getDocumentValidateStatus().getDesc());
						errors.add(docError);
					}
					
					ErrorGroupResponse redGroup = new ErrorGroupResponse();
					redGroup.setCode("99");
					redGroup.setDescription("Red");
					
					if(ValidateUtil.chkExpireDate(document.getExpireDate())){
						DocumentError docError = new DocumentError();
						docError.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
						docError.setDescription(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
						errors.add(docError);
						VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
						DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
						documentValidateStatus.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
						documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
						verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
						verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
					}
					
					Boolean isUsed = invalidateTransactionStatusDao.isRefIdAndDocIdAndDocTypeExists(refID , rqDocId , rqDocType);
					if(isUsed){
						DocumentError docError = new DocumentError();
						docError.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
						docError.setDescription(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
						errors.add(docError);
						VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
						DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
						documentValidateStatus.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
						documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
						verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
						verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
					}
					
					String statusOldRule = StringUtils.trimToEmpty(verifytransactionItem.getDisplayStatus().getCode());
					String status = StatusWS.GREEN.getCode();
					List<String> errorList = new ArrayList<String>();
					for (DocumentError error : errors) {
						errorList.add(error.getCode());
					}
					String[] arrayErrors = new String[errorList.size()];
					arrayErrors = errorList.toArray(arrayErrors);
					if(OLD_OPEN_ACC_MENU_ID.equals(svRq.getCode())){
						status = statusOldRule;
						int[] services = { SERVICE_OLD_OPEN_ACC_ID };
						ExecutionResult results = core.execute(services, arrayErrors);
						errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
					} else
					if(NEW_OPEN_ACC_MENU_ID.equals(svRq.getCode())){
						int[] services = { SERVICE_NEW_OPEN_ACC_ID };
						ExecutionResult results = core.execute(services, arrayErrors);
						Rule rule = results.getRules().get(0);
						for (com.kasikornbank.idva.core.result.ExecutionResult.Service service : rule.getServices()) {
							if(SERVICE_NEW_OPEN_ACC_ID == service.getId()){
								if(Status.RED.equals(service.getStatus())){
									status = StatusWS.RED.getCode();
								} else 
								if(Status.GRAY.equals(service.getStatus())){
									status = StatusWS.GRAY.getCode();
								}
							}
						}
						if("03".equals(statusOldRule)){
							status = statusOldRule;
						}
						errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
					} else 
					if(NDID_MENU_ID.equals(svRq.getCode())){
						int[] services = { SERVICE_NDID_ID };
						ExecutionResult results = core.execute(services, arrayErrors);
						Rule rule = results.getRules().get(0);
						for (com.kasikornbank.idva.core.result.ExecutionResult.Service service : rule.getServices()) {
							if(SERVICE_NDID_ID == service.getId()){
								if(Status.RED.equals(service.getStatus())){
									status = StatusWS.RED.getCode();
								} else 
								if(Status.GRAY.equals(service.getStatus())){
									status = StatusWS.GRAY.getCode();
								}
							}
						}
						if("03".equals(statusOldRule)){
							status = statusOldRule;
						}
						errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
					}
					
					document.setId(rqDocId);
					document.setStatus(status);
					document.setErrorGroups(errorGroupList);
					documentServiceList.add(document);
				}
				else {
					ErrorGroupResponse errorGroup = new ErrorGroupResponse();
					List<DocumentError> errors = new ArrayList<DocumentError>();
					
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_NOT_FOUND_REF_ID_DOC_ID);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID_DOC_ID"));
					errors.add(docError);
					
					errorGroup.setCode("99");
					errorGroup.setDescription("Red");
					errorGroup.setErrors(errors);
					errorGroupList.add(errorGroup);
					
					document.setId(rqDocId);
					document.setStatus(StatusWS.RED.getCode());
					document.setErrorGroups(errorGroupList);
					documentServiceList.add(document);
				}
				
			}
			
			List<DocumentServiceResponse> chkResponseStatus = documentServiceList;	
			String statusWS = StatusWS.GREEN.getCode();
			Boolean chkGray = false;
			for(DocumentServiceResponse rs : chkResponseStatus){
				if(StatusWS.RED.getCode().equals(rs.getStatus())){
					statusWS = StatusWS.RED.getCode();
					break;
				}
				if(StatusWS.GRAY.getCode().equals(rs.getStatus())){
					statusWS = StatusWS.GRAY.getCode();
					chkGray = true;
				}
			}
			if(!StatusWS.RED.getCode().equals(statusWS) && chkGray){
				statusWS = StatusWS.GRAY.getCode();
			} 
			
			serviceResponse.setStatus(statusWS);
			serviceResponse.setCode(svRq.getCode());
			serviceResponse.setDescription(getServiceDescription(svRq.getCode()));
			serviceResponse.setDocumentServices(documentServiceList);
			serviceResponses.add(serviceResponse);
		}
		
		
		response.setNumberOfValid(numberOfValid);
		response.setNumberOfInValid(numberOfInValid);
		response.setNumberOfRefId(numberOfRefID);
		response.setDocuments(documents);
		response.setServices(serviceResponses);
		response.setReferDocumentFlag(ReferDocFlag.YES.getCode());
	}
	
	private void inquiryVerifyDocFlagNo(InquiryVerifyRequest request , InquiryVerifyResponse response ) throws IDVAException{
		String refID = request.getRefId();
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refID);
		response.setReferDocumentFlag(ReferDocFlag.NO.getCode());
		verifyTransaction = verifyTransactionDao.getRefIdAndStatus(verifyTransaction,RecordStatus.ACTIVE.name());
		if(verifyTransaction == null){
			throw new IDVAException("1001", ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID"));
		}
		List<DocumentResponse> documentResponses = new ArrayList<DocumentResponse>();
		List<VerifyTransactionItem> listVerifytransactionItems = verifyTransaction.getVerifyTransactionItems();
		int numberOfRefID = listVerifytransactionItems.size();
		int numberOfValid = 0;
		int numberOfInValid = 0;
		
		for(VerifyTransactionItem verifytransactionItem : listVerifytransactionItems){
			String expireDate = verifytransactionItem.getCardExp();
			String docType = (verifytransactionItem.getDocumentType().getDocumentTypeId() == null) 
					? "":verifytransactionItem.getDocumentType().getDocumentTypeId().toString();
			String docId = (StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId()) != "")?StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId())
					: StringUtils.trimToEmpty(verifytransactionItem.getDocId());
			DocumentResponse documentResponse = new DocumentResponse();
			documentResponse.setDocumentType(docType);
			documentResponse.setDocumentId(docId);
			documentResponse.setDateOfBirth((!StringUtils.trimToEmpty(verifytransactionItem.getSrcDob()).equals("")) ? StringUtils.trimToEmpty(verifytransactionItem.getSrcDob())
					: StringUtils.trimToEmpty(verifytransactionItem.getDob()));
			documentResponse.setDateOfBirth(ValidateUtil.formateThToUs(documentResponse.getDateOfBirth()));
			documentResponse.setName( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcName()).equals(""))? StringUtils.trimToEmpty(verifytransactionItem.getSrcName())
					: StringUtils.trimToEmpty(verifytransactionItem.getName()));
			documentResponse.setSurename( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName())
					: StringUtils.trimToEmpty(verifytransactionItem.getLstName()));
			documentResponse.setChannel( (ReadFromCard.YES == verifytransactionItem.getReadFromCard())? ReadFromCard.YES.getDesc() :  ReadFromCard.NO.getDesc());
			documentResponse.setExpireDate(ValidateUtil.formateThToUs(expireDate));
			documentResponse.setNatCode( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode()).equals("") )?StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode())
					:StringUtils.trimToEmpty(verifytransactionItem.getNationCode()));
			
			if(null != verifytransactionItem.getVerifyTransactionItemExtend()){
				setItemExtend(verifytransactionItem, documentResponse);
			}
			
			List<VerifyTransactionItemStatus> itemsStatus = verifytransactionItem.getVerifyTransactionItemStatus();
			List<DocumentError> errors = new ArrayList<DocumentError>();
			for(VerifyTransactionItemStatus itemStatus : itemsStatus){
				DocumentError docError = new DocumentError();
				docError.setCode(itemStatus.getDocumentValidateStatus().getCode());
				docError.setDescription(itemStatus.getDocumentValidateStatus().getDesc());
				errors.add(docError);
			}
			
			VerifyTransactionCode verifyTransactionCode = verifyTransaction.getVerifyTransactionCode();
			boolean ignoreExpDate = false;
			if(verifyTransactionCode!=null) {
				ignoreExpDate = verifyTransactionDao.getIgnoreValidateExpireDate(verifyTransactionCode.getCode());
			}
			if(!ignoreExpDate && ValidateUtil.chkExpireDate(documentResponse.getExpireDate())){
				DocumentError docError = new DocumentError();
				docError.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
				docError.setDescription(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
				errors.add(docError);
				VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
				DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
				documentValidateStatus.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
				documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
				verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
				verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
			}
			Boolean isUsed = invalidateTransactionStatusDao.isRefIdAndDocIdAndDocTypeExists(refID, docId, docType);
			if(isUsed){
				DocumentError docError = new DocumentError();
				docError.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
				docError.setDescription(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
				errors.add(docError);
				VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
				DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
				documentValidateStatus.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
				documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
				verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
				verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
			}
			if( errors.size() == 0 ){
				numberOfValid++;
			}else if (errors.size() > 0){
				numberOfInValid++;
			}
			documentResponse.setStatus(StringUtils.trimToEmpty(verifytransactionItem.getDisplayStatus().getCode()));
			documentResponse.setErrors(errors);
			documentResponses.add(documentResponse);
		}
		response.setNumberOfValid(numberOfValid);
		response.setNumberOfInValid(numberOfInValid);
		response.setNumberOfRefId(numberOfRefID);
		response.setDocuments(documentResponses);
		List<DocumentResponse> chkResponseStatus = response.getDocuments();
		String statusWS = StatusWS.GREEN.getCode();
		Boolean chkGray = false;
		for(DocumentResponse rs : chkResponseStatus){
			if(StatusWS.RED.getCode().equals(rs.getStatus())){
				statusWS = StatusWS.RED.getCode();
				break;
			}
			if(StatusWS.GRAY.getCode().equals(rs.getStatus())){
				statusWS = StatusWS.GRAY.getCode();
				chkGray = true;
			}
		}
		if(!StatusWS.RED.getCode().equals(statusWS) && chkGray){
			statusWS = StatusWS.GRAY.getCode();
		} 
		//String statusWS = chkResponseStatus.stream().filter(i -> StringUtils.isNotEmpty(i.getStatus())).map(DocumentResponse::getStatus).max(Comparator.comparing(Integer::parseInt)).get();
		response.setStatus(statusWS);
		response.setDocuments(documentResponses);
	}
	
	private void inquiryVerifyWithServicesDocFlagNo(InquiryVerifyRequest request , InquiryVerifyWithServicesResponse response ) throws IDVAException{
		String refID = request.getRefId();
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refID);
		verifyTransaction = verifyTransactionDao.getRefIdAndStatus(verifyTransaction,RecordStatus.ACTIVE.name());
		if(verifyTransaction == null){
			throw new IDVAException("1001", ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID"));
		}
		
		List<DocumentServiceResponse> documents = new ArrayList<DocumentServiceResponse>();
		List<SereviceResponse> serviceResponses = new ArrayList<SereviceResponse>();
		List<ServiceRequest> serviceRequest = request.getServiceRequest();
		
		
		List<VerifyTransactionItem> listVerifytransactionItems = verifyTransaction.getVerifyTransactionItems();
		int numberOfRefID = listVerifytransactionItems.size();
		int numberOfValid = 0;
		int numberOfInValid = 0;
		
		for(VerifyTransactionItem verifytransactionItem : listVerifytransactionItems){
			DocumentServiceResponse documentResponse = new DocumentServiceResponse();
			String expireDate = verifytransactionItem.getCardExp();
			AdditionalDocument additionalDocument = verifytransactionItem.getAdditionalDocument();
			documentResponse.setType((verifytransactionItem.getDocumentType().getDocumentTypeId() == null) 
					? "":verifytransactionItem.getDocumentType().getDocumentTypeId().toString());
			documentResponse.setId( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId())
					: StringUtils.trimToEmpty(verifytransactionItem.getDocId()));
			documentResponse.setDateOfBirth( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDob()).equals("")) ? StringUtils.trimToEmpty(verifytransactionItem.getSrcDob())
					: StringUtils.trimToEmpty(verifytransactionItem.getDob()));
			documentResponse.setDateOfBirth(ValidateUtil.formateThToUs(documentResponse.getDateOfBirth()));
			documentResponse.setName( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcName()).equals(""))? StringUtils.trimToEmpty(verifytransactionItem.getSrcName())
					: StringUtils.trimToEmpty(verifytransactionItem.getName()));
			documentResponse.setSurname( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName())
					: StringUtils.trimToEmpty(verifytransactionItem.getLstName()));
			documentResponse.setChannel( (ReadFromCard.YES == verifytransactionItem.getReadFromCard())? ReadFromCard.YES.getDesc() :  ReadFromCard.NO.getDesc());
			documentResponse.setExpireDate(ValidateUtil.formateThToUs(expireDate));
			documentResponse.setNatCode( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode()).equals("") )?StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode())
					:StringUtils.trimToEmpty(verifytransactionItem.getNationCode()));
			if(null != additionalDocument){
				documentResponse.setAttachDocCode((StringUtils.trimToEmpty(additionalDocument.getCode()).equals("") )?"":StringUtils.trimToEmpty(additionalDocument.getCode()));
				documentResponse.setAttachDocDesc((StringUtils.trimToEmpty(additionalDocument.getDesc()).equals("") )?"":StringUtils.trimToEmpty(additionalDocument.getDesc()));
			}
			documents.add(documentResponse);
		}
		
		for(ServiceRequest svRq : serviceRequest) {
			
			SereviceResponse serviceResponse = new SereviceResponse();
			List<DocumentServiceResponse> documentServiceList = new ArrayList<DocumentServiceResponse>();
			
			for(VerifyTransactionItem verifytransactionItem : listVerifytransactionItems){
				
				DocumentServiceResponse document = new DocumentServiceResponse();
				
				String expireDate = verifytransactionItem.getCardExp();
				String docType = (verifytransactionItem.getDocumentType().getDocumentTypeId() == null) 
						? "":verifytransactionItem.getDocumentType().getDocumentTypeId().toString();
				String docId = (StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId()) != "")?StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId())
						: StringUtils.trimToEmpty(verifytransactionItem.getDocId());
				
				document.setExpireDate(ValidateUtil.formateThToUs(expireDate));	
				List<VerifyTransactionItemStatus> itemsStatus = verifytransactionItem.getVerifyTransactionItemStatus();
				List<ErrorGroupResponse> errorGroupList = new ArrayList<ErrorGroupResponse>();
				
				List<DocumentError> errors = new ArrayList<DocumentError>();
				for(VerifyTransactionItemStatus itemStatus : itemsStatus){
					DocumentError docError = new DocumentError();
					docError.setCode(itemStatus.getDocumentValidateStatus().getCode());
					docError.setDescription(itemStatus.getDocumentValidateStatus().getDesc());
					errors.add(docError);
				}
				
				if(ValidateUtil.chkExpireDate(document.getExpireDate())){
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
					errors.add(docError);
					VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
					DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
					documentValidateStatus.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
					documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
					verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
					verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
				}
				Boolean isUsed = invalidateTransactionStatusDao.isRefIdAndDocIdAndDocTypeExists(refID, docId, docType);
				if(isUsed){
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
					errors.add(docError);
					VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
					DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
					documentValidateStatus.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
					documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
					verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
					verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
				}

				String statusOldRule = StringUtils.trimToEmpty(verifytransactionItem.getDisplayStatus().getCode());
				String status = StatusWS.GREEN.getCode();
				
				List<String> errorList = new ArrayList<String>();
				for (DocumentError error : errors) {
					errorList.add(error.getCode());
				}
				String[] arrayErrors = new String[errorList.size()];
				arrayErrors = errorList.toArray(arrayErrors);
				
				if(OLD_OPEN_ACC_MENU_ID.equals(svRq.getCode())){
					status = statusOldRule;
					int[] services = { SERVICE_OLD_OPEN_ACC_ID };
					ExecutionResult results = core.execute(services, arrayErrors);
					errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
				} else
				if(NEW_OPEN_ACC_MENU_ID.equals(svRq.getCode())){
					int[] services = { SERVICE_NEW_OPEN_ACC_ID };
					ExecutionResult results = core.execute(services, arrayErrors);
					Rule rule = results.getRules().get(0);
					for (com.kasikornbank.idva.core.result.ExecutionResult.Service service : rule.getServices()) {
						if(SERVICE_NEW_OPEN_ACC_ID == service.getId()){
							if(Status.RED.equals(service.getStatus())){
								status = StatusWS.RED.getCode();
							} else 
							if(Status.GRAY.equals(service.getStatus())){
								status = StatusWS.GRAY.getCode();
							}
						}
					}
					if("03".equals(statusOldRule)){
						status = statusOldRule;
					}
					errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
				} else 
				if(NDID_MENU_ID.equals(svRq.getCode())){
					int[] services = { SERVICE_NDID_ID };
					ExecutionResult results = core.execute(services, arrayErrors);
					Rule rule = results.getRules().get(0);
					for (com.kasikornbank.idva.core.result.ExecutionResult.Service service : rule.getServices()) {
						if(SERVICE_NDID_ID == service.getId()){
							if(Status.RED.equals(service.getStatus())){
								status = StatusWS.RED.getCode();
							} else 
							if(Status.GRAY.equals(service.getStatus())){
								status = StatusWS.GRAY.getCode();
							}
						}
					}
					if("03".equals(statusOldRule)){
						status = statusOldRule;
					}
					errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
				}
				
				document.setId(docId);
				document.setStatus(status);
				document.setErrorGroups(errorGroupList);
				documentServiceList.add(document);
				
			}
			
			List<DocumentServiceResponse> chkResponseStatus = documentServiceList;
			String statusWS = StatusWS.GREEN.getCode();
			Boolean chkGray = false;
			for(DocumentServiceResponse rs : chkResponseStatus){
				if(StatusWS.RED.getCode().equals(rs.getStatus())){
					statusWS = StatusWS.RED.getCode();
					break;
				}
				if(StatusWS.GRAY.getCode().equals(rs.getStatus())){
					statusWS = StatusWS.GRAY.getCode();
					chkGray = true;
				}
			}
			if(!StatusWS.RED.getCode().equals(statusWS) && chkGray){
				statusWS = StatusWS.GRAY.getCode();
			}
			
			serviceResponse.setStatus(statusWS);
			serviceResponse.setCode(svRq.getCode());
			serviceResponse.setDescription(getServiceDescription(svRq.getCode()));
			serviceResponse.setDocumentServices(documentServiceList);
			serviceResponses.add(serviceResponse);
		}
		
		response.setReferDocumentFlag(ReferDocFlag.NO.getCode());
		response.setNumberOfValid(numberOfValid);
		response.setNumberOfInValid(numberOfInValid);
		response.setNumberOfRefId(numberOfRefID);
		response.setDocuments(documents);
		response.setServices(serviceResponses);
	}
	
	private void inquiryVerifyByAccountNoDocFlagNo(String refID, InquiryVerifyRequest request , InquiryVerifyByAccountNoResponse response) throws IDVAException{
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refID);
		verifyTransaction = verifyTransactionDao.getRefIdAndStatus(verifyTransaction,RecordStatus.ACTIVE.name());
		if(verifyTransaction == null){
			throw new IDVAException("1001", ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID"));
		}
		
		List<DocumentServiceResponse> documents = new ArrayList<DocumentServiceResponse>();
		List<SereviceResponse> serviceResponses = new ArrayList<SereviceResponse>();
		List<ServiceRequest> serviceRequest = request.getServiceRequest();
		
		
		List<VerifyTransactionItem> listVerifytransactionItems = verifyTransaction.getVerifyTransactionItems();
		int numberOfRefID = listVerifytransactionItems.size();
		int numberOfValid = 0;
		int numberOfInValid = 0;
		
		for(VerifyTransactionItem verifytransactionItem : listVerifytransactionItems){
			DocumentServiceResponse documentResponse = new DocumentServiceResponse();
			String expireDate = verifytransactionItem.getCardExp();
			AdditionalDocument additionalDocument = verifytransactionItem.getAdditionalDocument();
			documentResponse.setType((verifytransactionItem.getDocumentType().getDocumentTypeId() == null) 
					? "":verifytransactionItem.getDocumentType().getDocumentTypeId().toString());
			documentResponse.setId( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId())
					: StringUtils.trimToEmpty(verifytransactionItem.getDocId()));
			documentResponse.setDateOfBirth( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcDob()).equals("")) ? StringUtils.trimToEmpty(verifytransactionItem.getSrcDob())
					: StringUtils.trimToEmpty(verifytransactionItem.getDob()));
			documentResponse.setDateOfBirth(ValidateUtil.formateThToUs(documentResponse.getDateOfBirth()));
			documentResponse.setName( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcName()).equals(""))? StringUtils.trimToEmpty(verifytransactionItem.getSrcName())
					: StringUtils.trimToEmpty(verifytransactionItem.getName()));
			documentResponse.setSurname( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName()).equals(""))?StringUtils.trimToEmpty(verifytransactionItem.getSrcLstName())
					: StringUtils.trimToEmpty(verifytransactionItem.getLstName()));
			documentResponse.setChannel( (ReadFromCard.YES == verifytransactionItem.getReadFromCard())? ReadFromCard.YES.getDesc() :  ReadFromCard.NO.getDesc());
			documentResponse.setExpireDate(ValidateUtil.formateThToUs(expireDate));
			documentResponse.setNatCode( (!StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode()).equals("") )?StringUtils.trimToEmpty(verifytransactionItem.getSrcNationCode())
					:StringUtils.trimToEmpty(verifytransactionItem.getNationCode()));
			if(null != additionalDocument){
				documentResponse.setAttachDocCode((StringUtils.trimToEmpty(additionalDocument.getCode()).equals("") )?"":StringUtils.trimToEmpty(additionalDocument.getCode()));
				documentResponse.setAttachDocDesc((StringUtils.trimToEmpty(additionalDocument.getDesc()).equals("") )?"":StringUtils.trimToEmpty(additionalDocument.getDesc()));
			}
			documents.add(documentResponse);
		}
		
		for(ServiceRequest svRq : serviceRequest) {
			
			SereviceResponse serviceResponse = new SereviceResponse();
			List<DocumentServiceResponse> documentServiceList = new ArrayList<DocumentServiceResponse>();
			
			for(VerifyTransactionItem verifytransactionItem : listVerifytransactionItems){
				
				DocumentServiceResponse document = new DocumentServiceResponse();
				
				String expireDate = verifytransactionItem.getCardExp();
				String docType = (verifytransactionItem.getDocumentType().getDocumentTypeId() == null) 
						? "":verifytransactionItem.getDocumentType().getDocumentTypeId().toString();
				String docId = (StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId()) != "")?StringUtils.trimToEmpty(verifytransactionItem.getSrcDocId())
						: StringUtils.trimToEmpty(verifytransactionItem.getDocId());
				
				document.setExpireDate(ValidateUtil.formateThToUs(expireDate));
				List<VerifyTransactionItemStatus> itemsStatus = verifytransactionItem.getVerifyTransactionItemStatus();
				List<ErrorGroupResponse> errorGroupList = new ArrayList<ErrorGroupResponse>();
				
				List<DocumentError> errors = new ArrayList<DocumentError>();
				for(VerifyTransactionItemStatus itemStatus : itemsStatus){
					DocumentError docError = new DocumentError();
					docError.setCode(itemStatus.getDocumentValidateStatus().getCode());
					docError.setDescription(itemStatus.getDocumentValidateStatus().getDesc());
					errors.add(docError);
				}
				
				if(ValidateUtil.chkExpireDate(document.getExpireDate())){
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
					errors.add(docError);
					VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
					DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
					documentValidateStatus.setCode(DocumentValidateStatus.ERROR_CARD_EXPIRE);
					documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_CARD_EXPIRE"));
					verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
					verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
				}
				Boolean isUsed = invalidateTransactionStatusDao.isRefIdAndDocIdAndDocTypeExists(refID, docId, docType);
				if(isUsed){
					DocumentError docError = new DocumentError();
					docError.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
					docError.setDescription(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
					errors.add(docError);
					VerifyTransactionItemStatus verifyTransactionItemStatus = new VerifyTransactionItemStatus();
					DocumentValidateStatus documentValidateStatus = new DocumentValidateStatus();
					documentValidateStatus.setCode(DocumentValidateStatus.ERROR_REF_ID_DOC_ID_IS_USED);
					documentValidateStatus.setDesc(ApplicationConfig.RB.getString("ERROR_REF_ID_DOC_ID_IS_USED"));
					verifyTransactionItemStatus.setDocumentValidateStatus(documentValidateStatus);
					verifytransactionItem.addItemStatus(verifyTransactionItemStatus);
				}

				String statusOldRule = StringUtils.trimToEmpty(verifytransactionItem.getDisplayStatus().getCode());
				String status = StatusWS.GREEN.getCode();
				
				List<String> errorList = new ArrayList<String>();
				for (DocumentError error : errors) {
					errorList.add(error.getCode());
				}
				String[] arrayErrors = new String[errorList.size()];
				arrayErrors = errorList.toArray(arrayErrors);
				
				if(OLD_OPEN_ACC_MENU_ID.equals(svRq.getCode())){
					status = statusOldRule;
					int[] services = { SERVICE_OLD_OPEN_ACC_ID };
					ExecutionResult results = core.execute(services, arrayErrors);
					errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
				} else
				if(NEW_OPEN_ACC_MENU_ID.equals(svRq.getCode())){
					int[] services = { SERVICE_NEW_OPEN_ACC_ID };
					ExecutionResult results = core.execute(services, arrayErrors);
					Rule rule = results.getRules().get(0);
					for (com.kasikornbank.idva.core.result.ExecutionResult.Service service : rule.getServices()) {
						if(SERVICE_NEW_OPEN_ACC_ID == service.getId()){
							if(Status.RED.equals(service.getStatus())){
								status = StatusWS.RED.getCode();
							} else 
							if(Status.GRAY.equals(service.getStatus())){
								status = StatusWS.GRAY.getCode();
							}
						}
					}
					if("03".equals(statusOldRule)){
						status = statusOldRule;
					}
					errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
				} else 
				if(NDID_MENU_ID.equals(svRq.getCode())){
					int[] services = { SERVICE_NDID_ID };
					ExecutionResult results = core.execute(services, arrayErrors);
					Rule rule = results.getRules().get(0);
					for (com.kasikornbank.idva.core.result.ExecutionResult.Service service : rule.getServices()) {
						if(SERVICE_NDID_ID == service.getId()){
							if(Status.RED.equals(service.getStatus())){
								status = StatusWS.RED.getCode();
							} else 
							if(Status.GRAY.equals(service.getStatus())){
								status = StatusWS.GRAY.getCode();
							}
						}
					}
					if("03".equals(statusOldRule)){
						status = statusOldRule;
					}
					errorGroupList = ErrorGroupUtils.getErrorGroups(errors, results.getGroups());
				}
				
				document.setId(docId);
				document.setStatus(status);
				document.setErrorGroups(errorGroupList);
				documentServiceList.add(document);
				
			}
			
			List<DocumentServiceResponse> chkResponseStatus = documentServiceList;
			String statusWS = StatusWS.GREEN.getCode();
			Boolean chkGray = false;
			for(DocumentServiceResponse rs : chkResponseStatus){
				if(StatusWS.RED.getCode().equals(rs.getStatus())){
					statusWS = StatusWS.RED.getCode();
					break;
				}
				if(StatusWS.GRAY.getCode().equals(rs.getStatus())){
					statusWS = StatusWS.GRAY.getCode();
					chkGray = true;
				}
			}
			if(!StatusWS.RED.getCode().equals(statusWS) && chkGray){
				statusWS = StatusWS.GRAY.getCode();
			}
			
			serviceResponse.setStatus(statusWS);
			serviceResponse.setCode(svRq.getCode());
			serviceResponse.setDescription(getServiceDescription(svRq.getCode()));
			serviceResponse.setDocumentServices(documentServiceList);
			serviceResponses.add(serviceResponse);
		}
		
		response.setReferDocumentFlag(ReferDocFlag.NO.getCode());
		response.setNumberOfValid(numberOfValid);
		response.setNumberOfInValid(numberOfInValid);
		response.setNumberOfRefId(numberOfRefID);
		response.setDocuments(documents);
		response.setServices(serviceResponses);
	}
	
	private void invalidateDocFlagYes(InvalidateVerifyStatusRequest request) throws IDVAException{
		String refID = request.getRefId();
		String refId = StringUtils.trimToEmpty(refID);
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refId);
		Boolean hasRefID = verifyTransactionDao.chkRefIdStatus(refID, RecordStatus.ACTIVE.name());
		if( !hasRefID ){
			throw new IDVAException("", String.format(ApplicationConfig.RB.getString("ERROR_REF_ID_IS_NOT_VALID"), refID));
		}
		
		for ( DocumentRequest documentRequest : request.getDocuments() ) {
			if(documentRequest == null){
				continue;
			}
			String rqDocId = StringUtils.trimToEmpty(documentRequest.getDocumentId());
			String rqDocType = StringUtils.trimToEmpty(documentRequest.getDocumentType());
			
			if((StringUtils.isEmpty(rqDocId) || StringUtils.isEmpty(rqDocType)) ||
					(StringUtils.isEmpty(rqDocId) && StringUtils.isEmpty(rqDocType)) ){
				throw new IDVAException("", ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"));
			}
			VerifyTransactionItem verifytransactionItem = verifyTransactionDao.getItemsByDocIdAndDocType(refId,rqDocId, rqDocType);
			Boolean valid = false;
			if((verifytransactionItem != null) && ( rqDocId.equals(verifytransactionItem.getDocId()) | rqDocId.equals(verifytransactionItem.getSrcDocId()) )
					&& (rqDocType.equals(verifytransactionItem.getDocumentType().getDocumentTypeId().toString())) ){
				valid = true;
			}
			if(!valid){
				throw new IDVAException("",String.format(ApplicationConfig.RB.getString("ERROR_DOCID_DOCTYPE_IS_NOT_VALID") , rqDocId , rqDocType));
			}
		}
		InvalidateTransactionStatus invalidateTransaction = new InvalidateTransactionStatus();
		invalidateTransaction.setAppId(StringUtils.trimToEmpty(request.getKbankHeader().getRqAppId()));
		invalidateTransaction.setRefId(StringUtils.trimToEmpty(refID));
		invalidateTransaction.setTransDesc(StringUtils.trimToEmpty(request.getTransDesc()));
		invalidateTransaction.setCreateBy("SYSTEM");
		invalidateTransaction.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
		invalidateTransaction.setAccountNo(StringUtils.trimToEmpty(request.getAccountNo()));
		invalidateTransaction.setCreateDate(new Timestamp(new Date().getTime()));
		invalidateTransaction.setTransTypeCode(request.getTransTypeCode());
		invalidateTransaction.setTransTypeDesc(request.getTransTypeDesc());
		
		invalidateTransaction.setAccountFund(StringUtils.trimToEmpty(request.getAccountFund()));
		invalidateTransaction.setCis(StringUtils.trimToEmpty(request.getCis()));
		invalidateTransaction.setDebitCard(StringUtils.trimToEmpty(request.getDebitCard()));
		invalidateTransaction.setCreditCard(StringUtils.trimToEmpty(request.getCreditCard()));
		invalidateTransaction.setOtherAcctType(StringUtils.trimToEmpty(request.getOtherAcctType()));
		invalidateTransaction.setOtherAcctNo(StringUtils.trimToEmpty(request.getOtherAcctNo()));
		
		List<DocumentRequest> documents = request.getDocuments();
		List<InvalidateTransactionItemStatus> items = new ArrayList<InvalidateTransactionItemStatus>();
		for(DocumentRequest document : documents){
			InvalidateTransactionItemStatus item = new InvalidateTransactionItemStatus();
			item.setRefId(refID);
			item.setDocument(document);
			items.add(item);
		}
		invalidateTransaction.setItems(items);
		try{
			invalidateTransactionStatusService.saveItems(invalidateTransaction);
		}catch(Exception e){
			LOGGER.info(String.format("Cannot Insert Invalidate table RefId = %s", refId));
			throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), ApplicationConfig.RB.getString("ERROR_DOCID_IS_DUP"));
		}
	
	}
	
	private void invalidateDocFlagNo(InvalidateVerifyStatusRequest request) throws IDVAException{
		String refID = request.getRefId();
		String refId = StringUtils.trimToEmpty(refID);
		InvalidateTransactionStatus invalidateTransaction = new InvalidateTransactionStatus();
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refId);
		verifyTransaction = verifyTransactionDao.getRefIdAndStatus(verifyTransaction,RecordStatus.ACTIVE.name());
		if(verifyTransaction == null){
			throw new IDVAException("", String.format(ApplicationConfig.RB.getString("ERROR_REF_ID_IS_NOT_VALID"), refID));
		}
		invalidateTransaction.setAppId(StringUtils.trimToEmpty(request.getKbankHeader().getRqAppId()));
		invalidateTransaction.setRefId(StringUtils.trimToEmpty(refID));
		invalidateTransaction.setTransDesc(StringUtils.trimToEmpty(request.getTransDesc()));
		invalidateTransaction.setAccountNo(StringUtils.trimToEmpty(request.getAccountNo()));
		invalidateTransaction.setCreateBy("SYSTEM");
		invalidateTransaction.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
		invalidateTransaction.setCreateDate(new Timestamp(new Date().getTime()));
		invalidateTransaction.setTransTypeCode(request.getTransTypeCode());
		invalidateTransaction.setTransTypeDesc(request.getTransTypeDesc());
		
		invalidateTransaction.setAccountFund(StringUtils.trimToEmpty(request.getAccountFund()));
		invalidateTransaction.setCis(StringUtils.trimToEmpty(request.getCis()));
		invalidateTransaction.setDebitCard(StringUtils.trimToEmpty(request.getDebitCard()));
		invalidateTransaction.setCreditCard(StringUtils.trimToEmpty(request.getCreditCard()));
		invalidateTransaction.setOtherAcctType(StringUtils.trimToEmpty(request.getOtherAcctType()));
		invalidateTransaction.setOtherAcctNo(StringUtils.trimToEmpty(request.getOtherAcctNo()));
		
		List<InvalidateTransactionItemStatus> inItems = new ArrayList<InvalidateTransactionItemStatus>();
		List<VerifyTransactionItem> items = verifyTransaction.getVerifyTransactionItems();
		for(VerifyTransactionItem item : items){
			DocumentRequest doc = new DocumentRequest();
			doc.setDocumentId( (StringUtils.trimToEmpty(item.getSrcDocId()) != "" ) ? StringUtils.trimToEmpty(item.getSrcDocId()) : StringUtils.trimToEmpty(item.getDocId()));
			doc.setDocumentType(item.getDocumentType().getDocumentTypeId().toString());
			InvalidateTransactionItemStatus inItem = new InvalidateTransactionItemStatus();
			inItem.setDocument(doc);
			inItem.setRefId(refId);
			inItems.add(inItem);
		}
		invalidateTransaction.setItems(inItems);
		try{
			invalidateTransactionStatusService.saveItems(invalidateTransaction);
		}catch(Exception e){
			LOGGER.info(String.format("Cannot Insert Invalidate table RefId = %s", refId));
			throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), ApplicationConfig.RB.getString("ERROR_DOCID_IS_DUP"));
		}
	
	}
	
	
	private void inquiryVerifyDocFlagNoSpecial(InquiryVerifyRequest request , InquiryVerifyResponse response , SpecialRefVerify specialRefVerify ) throws IDVAException{
		String refID = request.getRefId();
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refID);
		response.setReferDocumentFlag(ReferDocFlag.NO.getCode());
		verifyTransaction = verifyTransactionDao.getRefIdAndStatus(verifyTransaction,RecordStatus.ACTIVE.name());
		if(verifyTransaction == null){
			throw new IDVAException("1001", ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID"));
		}
		List<DocumentResponse> documentResponses = new ArrayList<DocumentResponse>();
		response.setNumberOfValid(0);
		response.setNumberOfInValid(0);
		response.setNumberOfRefId(0);
		response.setDocuments(documentResponses);
		String statusWS = StatusWS.GREEN.getCode();
		response.setStatus(statusWS);
		response.setDocuments(documentResponses);
	}
	
	private void inquiryVerifyWithServicesDocFlagNoSpecial(InquiryVerifyRequest request , InquiryVerifyWithServicesResponse response , SpecialRefVerify specialRefVerify ) throws IDVAException{
		String refID = request.getRefId();
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refID);
		response.setReferDocumentFlag(ReferDocFlag.NO.getCode());
		verifyTransaction = verifyTransactionDao.getRefIdAndStatus(verifyTransaction,RecordStatus.ACTIVE.name());
		if(verifyTransaction == null){
			throw new IDVAException("1001", ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID"));
		}
		List<DocumentServiceResponse> documentResponses = new ArrayList<DocumentServiceResponse>();
		response.setNumberOfValid(0);
		response.setNumberOfInValid(0);
		response.setNumberOfRefId(0);
		response.setDocuments(documentResponses);
		
		List<ServiceRequest> serviceRequest = request.getServiceRequest();
		List<SereviceResponse> sereviceResponse = new ArrayList<SereviceResponse>();
		for (ServiceRequest rq : serviceRequest) {
			SereviceResponse rs = new SereviceResponse();
			rs.setStatus(StatusWS.GREEN.getCode());
			rs.setCode(rq.getCode());
			rs.setDescription(getServiceDescription(rq.getCode()));
			sereviceResponse.add(rs);
		}
		response.setDocuments(documentResponses);
		response.setServices(sereviceResponse);
	}
	
	private void inquiryVerifyByAccountNoDocFlagNoSpecial(String refID, InquiryVerifyRequest request , InquiryVerifyByAccountNoResponse response , SpecialRefVerify specialRefVerify ) throws IDVAException{
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refID);
		response.setReferDocumentFlag(ReferDocFlag.NO.getCode());
		verifyTransaction = verifyTransactionDao.getRefIdAndStatus(verifyTransaction,RecordStatus.ACTIVE.name());
		if(verifyTransaction == null){
			throw new IDVAException("1001", ApplicationConfig.RB.getString("ERROR_NOT_FOUND_REF_ID"));
		}
		List<DocumentServiceResponse> documentResponses = new ArrayList<DocumentServiceResponse>();
		response.setNumberOfValid(0);
		response.setNumberOfInValid(0);
		response.setNumberOfRefId(0);
		response.setDocuments(documentResponses);
		
		List<ServiceRequest> serviceRequest = request.getServiceRequest();
		List<SereviceResponse> sereviceResponse = new ArrayList<SereviceResponse>();
		for (ServiceRequest rq : serviceRequest) {
			SereviceResponse rs = new SereviceResponse();
			rs.setStatus(StatusWS.GREEN.getCode());
			rs.setCode(rq.getCode());
			rs.setDescription(getServiceDescription(rq.getCode()));
			sereviceResponse.add(rs);
		}
		response.setDocuments(documentResponses);
		response.setServices(sereviceResponse);
	}
	
	private String getServiceDescription(String code){
		String desc = "";
		if ("01".equals(code)) desc = "เปิดบัญชีเก่า";
		else if ("02".equals(code)) desc = "เปิดบัญชีใหม่";
		else if ("03".equals(code)) desc = "Enroll NDID";
		return desc;
	}
	
	private void invalidateDocFlagYesSpecial(InvalidateVerifyStatusRequest request , SpecialRefVerify specialRefVerify) throws IDVAException{
		String refID = request.getRefId();
		String refId = StringUtils.trimToEmpty(refID);
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(refId);
		/*Boolean hasRefID = verifyTransactionDao.chkRefIdStatus(refID, RecordStatus.ACTIVE.name());
		if( !hasRefID ){
			throw new IDVAException("", String.format(ApplicationConfig.RB.getString("ERROR_REF_ID_IS_NOT_VALID"), refID));
		}*/
		
		String accountNo = StringUtils.trimToEmpty(request.getAccountNo());
		if(StringUtils.isEmpty(accountNo) || accountNo.length() != 10){
			throw new IDVAException("", ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"));
		}
		for ( DocumentRequest documentRequest : request.getDocuments() ) {
			if(documentRequest == null){
				continue;
			}
			String rqDocId = StringUtils.trimToEmpty(documentRequest.getDocumentId());
			String rqDocType = StringUtils.trimToEmpty(documentRequest.getDocumentType());
				
			if((StringUtils.isEmpty(rqDocId) || StringUtils.isEmpty(rqDocType)) ||
					(StringUtils.isEmpty(rqDocId) && StringUtils.isEmpty(rqDocType)) ){
				throw new IDVAException("", ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"));
			}
			
		}
		InvalidateTransactionStatus invalidateTransaction = new InvalidateTransactionStatus();
		invalidateTransaction.setAppId(StringUtils.trimToEmpty(request.getKbankHeader().getRqAppId()));
		invalidateTransaction.setRefId(StringUtils.trimToEmpty(refID));
		invalidateTransaction.setTransDesc(StringUtils.trimToEmpty(request.getTransDesc()));
		invalidateTransaction.setCreateBy(request.getKbankHeader().getUserId());
		invalidateTransaction.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
		invalidateTransaction.setAccountNo(StringUtils.trimToEmpty(request.getAccountNo()));
		invalidateTransaction.setCreateDate(new Timestamp(new Date().getTime()));
		invalidateTransaction.setVersion(specialRefVerify.getVersion());
		invalidateTransaction.setTransTypeCode(request.getTransTypeCode());
		invalidateTransaction.setTransTypeDesc(request.getTransTypeDesc());
		
		invalidateTransaction.setAccountFund(StringUtils.trimToEmpty(request.getAccountFund()));
		invalidateTransaction.setCis(StringUtils.trimToEmpty(request.getCis()));
		invalidateTransaction.setDebitCard(StringUtils.trimToEmpty(request.getDebitCard()));
		invalidateTransaction.setCreditCard(StringUtils.trimToEmpty(request.getCreditCard()));
		invalidateTransaction.setOtherAcctType(StringUtils.trimToEmpty(request.getOtherAcctType()));
		invalidateTransaction.setOtherAcctNo(StringUtils.trimToEmpty(request.getOtherAcctNo()));
		
		List<DocumentRequest> documents = request.getDocuments();
		List<InvalidateTransactionItemStatus> items = new ArrayList<InvalidateTransactionItemStatus>();
		for(DocumentRequest document : documents){
			InvalidateTransactionItemStatus item = new InvalidateTransactionItemStatus();
			item.setRefId(refID);
			item.setDocument(document);
			items.add(item);
		}
		invalidateTransaction.setItems(items);
		try{
			invalidateTransactionStatusService.saveItemsSpecial(invalidateTransaction);
		}catch(Exception e){
			LOGGER.info(String.format("Cannot Insert Invalidate table RefId = %s", refId));
			throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), ApplicationConfig.RB.getString("ERROR_DOCID_IS_DUP"));
		}
	}
	
	private void invalidateNewRef(InvalidateVerifyStatusRequest request) throws IDVAException{
		
		String newRefID = request.getRefId();
		String oldRefID = newRefID.replaceAll("[A-Z]{1,2}", "");
		
		InvalidateTransactionStatus invalidateTransaction = new InvalidateTransactionStatus();
		VerifyTransaction verifyTransaction = new VerifyTransaction();
		verifyTransaction.setRefId(oldRefID);
		verifyTransaction = verifyTransactionDao.getRefIdForNewRef(verifyTransaction);
		if(verifyTransaction == null){
			throw new IDVAException("", String.format(ApplicationConfig.RB.getString("ERROR_REF_ID_IS_NOT_VALID"), oldRefID));
		}
		
		VerifyTransaction newVerify = new VerifyTransaction();
		newVerify = verifyTransaction;
		newVerify.setRefId(newRefID);
		newVerify.setCreateDate(new Timestamp(new Date().getTime()));
		newVerify.setUpdateDate(new Timestamp(new Date().getTime()));
		
		try{
			verifyTransactionDao.save(newVerify);
		}catch(Exception e){
			LOGGER.info(String.format("Cannot Insert New Verify table RefId = %s", newRefID));
			throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), ApplicationConfig.RB.getString("ERROR_DOCID_IS_DUP"));
		}
		
		invalidateTransaction.setAppId(StringUtils.trimToEmpty(request.getKbankHeader().getRqAppId()));
		invalidateTransaction.setRefId(StringUtils.trimToEmpty(newRefID));
		invalidateTransaction.setTransDesc(StringUtils.trimToEmpty(request.getTransDesc()));
		invalidateTransaction.setAccountNo(StringUtils.trimToEmpty(request.getAccountNo()));
		invalidateTransaction.setCreateBy("SYSTEM");
		invalidateTransaction.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
		invalidateTransaction.setCreateDate(new Timestamp(new Date().getTime()));
		invalidateTransaction.setTransTypeCode(request.getTransTypeCode());
		invalidateTransaction.setTransTypeDesc(request.getTransTypeDesc());
		
		invalidateTransaction.setAccountFund(StringUtils.trimToEmpty(request.getAccountFund()));
		invalidateTransaction.setCis(StringUtils.trimToEmpty(request.getCis()));
		invalidateTransaction.setDebitCard(StringUtils.trimToEmpty(request.getDebitCard()));
		invalidateTransaction.setCreditCard(StringUtils.trimToEmpty(request.getCreditCard()));
		invalidateTransaction.setOtherAcctType(StringUtils.trimToEmpty(request.getOtherAcctType()));
		invalidateTransaction.setOtherAcctNo(StringUtils.trimToEmpty(request.getOtherAcctNo()));
		
		List<InvalidateTransactionItemStatus> inItems = new ArrayList<InvalidateTransactionItemStatus>();
		List<VerifyTransactionItem> items = verifyTransaction.getVerifyTransactionItems();
		for(VerifyTransactionItem item : items){
			DocumentRequest doc = new DocumentRequest();
			doc.setDocumentId( (StringUtils.trimToEmpty(item.getSrcDocId()) != "" ) ? StringUtils.trimToEmpty(item.getSrcDocId()) : StringUtils.trimToEmpty(item.getDocId()));
			doc.setDocumentType(item.getDocumentType().getDocumentTypeId().toString());
			InvalidateTransactionItemStatus inItem = new InvalidateTransactionItemStatus();
			inItem.setDocument(doc);
			inItem.setRefId(newRefID);
			inItems.add(inItem);
		}
		invalidateTransaction.setItems(inItems);
		try{
			invalidateTransactionStatusService.saveItems(invalidateTransaction);
		}catch(Exception e){
			LOGGER.info(String.format("Cannot Insert Invalidate table RefId = %s", newRefID));
			throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), ApplicationConfig.RB.getString("ERROR_DOCID_IS_DUP"));
		}
	}
	
	@Override
	public InquiryVerifyResponse inquiryVerify(InquiryVerifyRequest request) throws IDVAException {
		InquiryVerifyResponse response = new InquiryVerifyResponse();
		response.setRefId(request.getRefId());
		// check is special
		List<SpecialRefVerify> listSpecial = specialRefVerifyDao.getbyRefId(request.getRefId(),RecordStatus.ACTIVE.name());
		boolean isSpecialRef = listSpecial != null && listSpecial.size() > 0;
		if (request.getReferDocumentFlag().equals(ReferDocFlag.YES.getCode())) {
			if (isSpecialRef)
				throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), "No service implement.");
			else
				inquiryVerifyDocFlagYes(request, response);
		} else if (request.getReferDocumentFlag().equals(ReferDocFlag.NO.getCode())) {
			if (isSpecialRef)
				inquiryVerifyDocFlagNoSpecial(request, response, listSpecial.get(0));
			else
				inquiryVerifyDocFlagNo(request, response);
		}
		return response;
	}
	
	@Override
	public InquiryVerifyWithServicesResponse inquiryVerifyWithServices(InquiryVerifyRequest request) throws IDVAException {
		InquiryVerifyWithServicesResponse response = new InquiryVerifyWithServicesResponse();
		response.setRefId(request.getRefId());
		// check is special
		List<SpecialRefVerify> listSpecial = specialRefVerifyDao.getbyRefId(request.getRefId(),RecordStatus.ACTIVE.name());
		boolean isSpecialRef = listSpecial != null && listSpecial.size() > 0;
		if (request.getReferDocumentFlag().equals(ReferDocFlag.YES.getCode())) {
			if (isSpecialRef)
				throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), "No service implement.");
			else
				inquiryVerifyWithServicesDocFlagYes(request, response);
		} else if (request.getReferDocumentFlag().equals(ReferDocFlag.NO.getCode())) {
			if (isSpecialRef)
				inquiryVerifyWithServicesDocFlagNoSpecial(request, response, listSpecial.get(0));
			else
				inquiryVerifyWithServicesDocFlagNo(request, response);
		}
		return response;
	}
	
	@Override
	public InquiryVerifyByAccountNoResponse inquiryVerifyByAccountNo(InquiryVerifyRequest request)
			throws IDVAException {
		InquiryVerifyByAccountNoResponse response = new InquiryVerifyByAccountNoResponse();
		String accountNo = request.getAccountNo();
		response.setAccountNo(accountNo);
		// check is special
		VerifyTransactionByAccount vAccount = verifyTransactionByAccountDao.find(accountNo);
		if (vAccount == null){
			throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), "Not found referenceID with acoount : " + request.getAccountNo());
		}
		String refID = vAccount.getRefId();
		response.setRefId(refID);
		List<SpecialRefVerify> listSpecial = specialRefVerifyDao.getbyRefId(refID,RecordStatus.ACTIVE.name());
		boolean isSpecialRef = listSpecial != null && listSpecial.size() > 0;
		if (request.getReferDocumentFlag().equals(ReferDocFlag.YES.getCode())) {
			if (isSpecialRef)
				throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), "No service implement.");
			else
				inquiryVerifyByAccountNoDocFlagYes(refID, request, response);
		} else if (request.getReferDocumentFlag().equals(ReferDocFlag.NO.getCode())) {
			if (isSpecialRef)
				inquiryVerifyByAccountNoDocFlagNoSpecial(refID, request, response, listSpecial.get(0));
			else
				inquiryVerifyByAccountNoDocFlagNo(refID, request, response);
		}
		return response;
	}

	@Override
	public InvalidateVerifyStatusResponse invalidateVerifyStatus(InvalidateVerifyStatusRequest request) throws IDVAException {
		
		if(Pattern.matches("\\d{16,18}[A-Z]{1,2}", request.getRefId())){
			if(verifyTransactionDao.exists(request.getRefId())){
				throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), "RefId is duplicate.");
			}
			invalidateNewRef(request);
		} else {
			List<SpecialRefVerify> listSpecial = specialRefVerifyDao.getbyRefId(request.getRefId(), RecordStatus.ACTIVE.name());
			boolean isSpecialRef = listSpecial != null && listSpecial.size() > 0;
			if (request.getReferDocumentFlag().equals(ReferDocFlag.YES.getCode())) {
				if (isSpecialRef) 
					invalidateDocFlagYesSpecial(request, listSpecial.get(0));
				 else 
					invalidateDocFlagYes(request);
				
			} else if (request.getReferDocumentFlag().equals(ReferDocFlag.NO.getCode())) {
				if (isSpecialRef) 
					throw new IDVAException(StatusCodeEnums.BUSINESS_ERROR.getCode(), "No service implement yet.");
				else 
					invalidateDocFlagNo(request);		
			}
		}
		return new InvalidateVerifyStatusResponse();
	}

}
