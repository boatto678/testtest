package com.kasikornbank.idva.ws.utils;

import java.util.ResourceBundle;

public class ApplicationConfig {

	private ApplicationConfig() {
	}
	
	public static final ResourceBundle RB = ResourceBundle.getBundle("resources/messages");

	public static int APP_ID_IDVA = 681;
	public static String APP_NAME_IDVA = "IDVA";
	public static int APP_ID_DIH = 281;
	public static String IDVA_SERVICE_01_CODE = "IDVA0001";
	public static String IDVA_SERVICE_02_CODE = "IDVA0002";
	public static String IDVA_SERVICE_03_CODE = "IDVA0003";
	public static String IDVA_SERVICE_04_CODE = "IDVA0004";

}
