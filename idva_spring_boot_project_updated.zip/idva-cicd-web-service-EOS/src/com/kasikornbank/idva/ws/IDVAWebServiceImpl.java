package com.kasikornbank.idva.ws;

import static com.kasikornbank.idva.backend.utils.PropertiesUtil.getConfigValue;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import jakarta.annotation.Resource;
import jakarta.jws.WebService;
import jakarta.xml.ws.WebServiceContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;

import com.google.gson.Gson;
import com.kasikornbank.idva.backend.entity.DocumentRequest;
import com.kasikornbank.idva.backend.entity.SereviceResponse;
import com.kasikornbank.idva.backend.entity.ServiceRequest;
import com.kasikornbank.idva.backend.enums.StatusWS;
import com.kasikornbank.idva.backend.utils.StaticContextHolder;
import com.kasikornbank.idva.ws.elk.ELKLogCustomField;
import com.kasikornbank.idva.ws.elk.IdvaLog;
import com.kasikornbank.idva.ws.entity.Error;
import com.kasikornbank.idva.ws.entity.InquiryVerifyByAccountNoResponse;
import com.kasikornbank.idva.ws.entity.InquiryVerifyRequest;
import com.kasikornbank.idva.ws.entity.InquiryVerifyResponse;
import com.kasikornbank.idva.ws.entity.InquiryVerifyWithServicesResponse;
import com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusRequest;
import com.kasikornbank.idva.ws.entity.InvalidateVerifyStatusResponse;
import com.kasikornbank.idva.ws.entity.KBankHeaderRequest;
import com.kasikornbank.idva.ws.entity.KBankHeaderResponse;
import com.kasikornbank.idva.ws.enums.StatusCodeEnums;
import com.kasikornbank.idva.ws.excaption.IDVAException;
import com.kasikornbank.idva.ws.service.IDVAService;
import com.kasikornbank.idva.ws.utils.ApplicationConfig;
import com.kasikornbank.idva.ws.utils.ServiceUtil;

@WebService(endpointInterface = "com.kasikornbank.idva.ws.IDVAWebService", targetNamespace = "http://ws.idva.kasikornbank.com", portName = "IDVAWebServicePort", serviceName = "IDVAWebService")
public class IDVAWebServiceImpl implements IDVAWebService {

	private final static ObjectMapper mapper = new ObjectMapper();
	
	private static final Logger LOGGER = Logger.getLogger(IDVAWebServiceImpl.class);
	private static final org.apache.logging.log4j.Logger ELKLOG = org.apache.logging.log4j.LogManager.getLogger(IDVAWebServiceImpl.class);

	private ArrayList<Error> errors = null;
	private Error error = null;
	
	@Resource
	WebServiceContext context;
	
	private KBankHeaderRequest kBankHeaderRequest = null;

	private KBankHeaderResponse kBankHeaderResponse = null; 
	
	private static final String ERROR_SERVERITY = "4";
	
	private static final String SERVICE_OLD_OPEN_ACC_ID = "01";
	private static final String SERVICE_NEW_OPEN_ACC_ID = "02";
	private static final String SERVICE_NDID_ID = "03";

	@Override
	public InquiryVerifyResponse InquiryVerify(InquiryVerifyRequest request) {
		try{
			LOGGER.info(String.format("REQUEST InquiryVerify : %s", mapper.writeValueAsString(getInquiryVerifyRequestLog(request))));	
		}catch(Exception e){
			LOGGER.info(String.format("Cannot log REQUEST InquiryVerify. Error = %s",e.getMessage()));
		}
		String uuid = UUID.randomUUID().toString();
		String key = StringUtils.trimToEmpty(request.getKbankHeader().getRqUID());
		ServiceUtil.logRequest(request,uuid,key);
		IDVAService idvaService = StaticContextHolder.getBean(IDVAService.class);
		
		InquiryVerifyResponse response = new InquiryVerifyResponse();
		kBankHeaderResponse = new KBankHeaderResponse();
		errors = new ArrayList<Error>();
		errors = validateRequestInquiry(request);
		if(errors.size() > 0){
			LOGGER.info(String.format("INVALID_REQUEST [Error size=%s]", errors.size()));
			kBankHeaderResponse.setStatusCode(StatusCodeEnums.BUSINESS_ERROR.getCode());
			kBankHeaderResponse.setErrorVect(errors);
			response.setKbankHeader(kBankHeaderResponse);
			response.setStatus(StatusWS.RED.getCode());
			response.setRefId(StringUtils.trimToEmpty(request.getRefId()));
			response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
			response.setNumberOfValid(0);
			response.setNumberOfInValid(0);
			response.setNumberOfRefId(0);
		}else{
			try{
				response = idvaService.inquiryVerify(request);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.SUCCESS.getCode());
			}catch(IDVAException idvae){
//				LOGGER.error(idvae.toString(), idvae);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.BUSINESS_ERROR.getCode());
				errors = new ArrayList<Error>();
				error = new Error();
				error.setErrorAppId(String.valueOf(ApplicationConfig.APP_ID_IDVA));
				error.setErrorAppAbbrv(ApplicationConfig.APP_NAME_IDVA);
				error.setErrorDesc(idvae.getDesc());
				error.setErrorCode(idvae.getCode());
				errors.add(error);
				kBankHeaderResponse.setErrorVect(errors);
				response.setKbankHeader(kBankHeaderResponse);
				response.setRefId(StringUtils.trimToEmpty(request.getRefId()));
				response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
				response.setNumberOfValid(0);
				response.setNumberOfInValid(0);
				response.setNumberOfRefId(0);
				response.setStatus(StatusWS.RED.getCode());
			} catch( Exception e ) {
				LOGGER.error(e.toString(), e);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.SYSTEM_ERROR.getCode());
				errors = new ArrayList<Error>();
				error = new Error();
				error.setErrorAppId(String.valueOf(ApplicationConfig.APP_ID_IDVA));
				error.setErrorAppAbbrv(ApplicationConfig.APP_NAME_IDVA);
				error.setErrorCode(StatusCodeEnums.SYSTEM_ERROR.getCode());
				error.setErrorDesc("System error : " + e.toString());
				errors.add(error);
				kBankHeaderResponse.setErrorVect(errors);
				response.setKbankHeader(kBankHeaderResponse);
				response.setRefId(StringUtils.trimToEmpty(request.getRefId()));
				response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
				response.setStatus(StatusWS.RED.getCode());
				response.setNumberOfValid(0);
				response.setNumberOfInValid(0);
				response.setNumberOfRefId(0);
			}
		}
		genKbankHeaderInquiry(request, response);
		try{
			LOGGER.info(String.format("RESPONSE InquiryVerify : %s", mapper.writeValueAsString(getInquiryVerifyResponsetLog(response))));	
		}catch(Exception e){
			LOGGER.info(String.format("Cannot log RESPONSE InquiryVerify. Error = %s",e.getMessage()));
		}
		ServiceUtil.logResponse(response,uuid,key);
		
		IdvaLog idvalog = setLogValidate(request,response);
		ELKLogCustomField.elkLogInfo(ELKLOG , idvalog);
		
		return response;
	}
	
	@Override
	public InquiryVerifyWithServicesResponse InquiryVerifyWithServices(InquiryVerifyRequest request) {
		try{
			LOGGER.info(String.format("REQUEST InquiryVerify : %s", mapper.writeValueAsString(getInquiryVerifyRequestLog(request))));	
		}catch(Exception e){
			LOGGER.info(String.format("Cannot log REQUEST InquiryVerify. Error = %s",e.getMessage()));
		}
		String uuid = UUID.randomUUID().toString();
		String key = StringUtils.trimToEmpty(request.getKbankHeader().getRqUID());
		ServiceUtil.logRequest(request,uuid,key);
		IDVAService idvaService = StaticContextHolder.getBean(IDVAService.class);
		
		InquiryVerifyWithServicesResponse response = new InquiryVerifyWithServicesResponse();
		kBankHeaderResponse = new KBankHeaderResponse();
		errors = new ArrayList<Error>();
		errors = validateRequestInquiryWithServices(request);
		if(errors.size() > 0){
			
			LOGGER.info(String.format("INVALID_REQUEST [Error size=%s]", errors.size()));
			kBankHeaderResponse.setStatusCode(StatusCodeEnums.BUSINESS_ERROR.getCode());
			kBankHeaderResponse.setErrorVect(errors);
			
			
			List<ServiceRequest> serviceRequest = request.getServiceRequest();
			if(null != serviceRequest){
				for (ServiceRequest rq : serviceRequest) {
					List<SereviceResponse> services = new ArrayList<SereviceResponse>();
					SereviceResponse service = new SereviceResponse();
					service.setCode(rq.getCode());
					service.setDescription(getServiceDescription(rq.getCode()));
					service.setStatus(StatusWS.RED.getCode());
					services.add(service);
					response.setServices(services);
				}
			}
			response.setKbankHeader(kBankHeaderResponse);
			response.setRefId(StringUtils.trimToEmpty(request.getRefId()));
			response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
			response.setNumberOfValid(0);
			response.setNumberOfInValid(0);
			response.setNumberOfRefId(0);
			
		}else{
			try{
				response = idvaService.inquiryVerifyWithServices(request);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.SUCCESS.getCode());
			}catch(IDVAException idvae){
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.BUSINESS_ERROR.getCode());
				errors = new ArrayList<Error>();
				error = new Error();
				error.setErrorAppId(String.valueOf(ApplicationConfig.APP_ID_IDVA));
				error.setErrorAppAbbrv(ApplicationConfig.APP_NAME_IDVA);
				error.setErrorDesc(idvae.getDesc());
				error.setErrorCode(idvae.getCode());
				errors.add(error);
				kBankHeaderResponse.setErrorVect(errors);
				
				List<SereviceResponse> services = new ArrayList<SereviceResponse>();
				List<ServiceRequest> serviceRequest = request.getServiceRequest();
				for (ServiceRequest rq : serviceRequest) {
					SereviceResponse service = new SereviceResponse();
					service.setCode(rq.getCode());
					service.setDescription(getServiceDescription(rq.getCode()));
					service.setStatus(StatusWS.RED.getCode());
					services.add(service);
				}
				
				response.setKbankHeader(kBankHeaderResponse);
				response.setRefId(StringUtils.trimToEmpty(request.getRefId()));
				response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
				response.setNumberOfValid(0);
				response.setNumberOfInValid(0);
				response.setNumberOfRefId(0);
				response.setServices(services);
			} catch( Exception e ) {
				LOGGER.error(e.toString(), e);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.SYSTEM_ERROR.getCode());
				errors = new ArrayList<Error>();
				error = new Error();
				error.setErrorAppId(String.valueOf(ApplicationConfig.APP_ID_IDVA));
				error.setErrorAppAbbrv(ApplicationConfig.APP_NAME_IDVA);
				error.setErrorCode(StatusCodeEnums.SYSTEM_ERROR.getCode());
				error.setErrorDesc("System error : " + e.toString());
				errors.add(error);
				kBankHeaderResponse.setErrorVect(errors);
				
				List<SereviceResponse> services = new ArrayList<SereviceResponse>();
				List<ServiceRequest> serviceRequest = request.getServiceRequest();
				for (ServiceRequest rq : serviceRequest) {
					SereviceResponse service = new SereviceResponse();
					service.setCode(rq.getCode());
					service.setDescription(getServiceDescription(rq.getCode()));
					service.setStatus(StatusWS.RED.getCode());
					services.add(service);
				}
				
				response.setKbankHeader(kBankHeaderResponse);
				response.setRefId(StringUtils.trimToEmpty(request.getRefId()));
				response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
				response.setNumberOfValid(0);
				response.setNumberOfInValid(0);
				response.setNumberOfRefId(0);
				response.setServices(services);
			}
		}
		genKbankHeaderInquiryWithServices(request, response);
		try{
			LOGGER.info(String.format("RESPONSE InquiryVerify : %s", mapper.writeValueAsString(getInquiryVerifyWithServicesResponsetLog(response))));	
		}catch(Exception e){
			LOGGER.info(String.format("Cannot log RESPONSE InquiryVerify. Error = %s",e.getMessage()));
		}
		ServiceUtil.logResponse(response,uuid,key);
		IdvaLog idvalog = setLogValidate(request,response);
		ELKLogCustomField.elkLogInfo(ELKLOG , idvalog);
		return response;
	}

	@Override
	public InvalidateVerifyStatusResponse InvalidateVerifyStatus(InvalidateVerifyStatusRequest request) {
		try{
			LOGGER.info(String.format("REQUEST Invalidate : %s", mapper.writeValueAsString(getInvalidateVerifyStatusRequestLog(request))));	
		}catch(Exception e){
			LOGGER.info(String.format("Cannot log REQUEST Invalidate. Error = %s",e.getMessage()));
		}
		String uuid = UUID.randomUUID().toString();
		String key = StringUtils.trimToEmpty(request.getKbankHeader().getRqUID());
		ServiceUtil.logRequest(request,uuid,key);
		IDVAService idvaService = StaticContextHolder.getBean(IDVAService.class);
		
		InvalidateVerifyStatusResponse response = new InvalidateVerifyStatusResponse();
		kBankHeaderResponse = new KBankHeaderResponse();
		errors = new ArrayList<Error>();
		errors = validateInvalidate(request);
		if(errors.size() > 0){
			LOGGER.info(String.format("INVALID_REQUEST [Error size=%s]", errors.size()));
			kBankHeaderResponse.setStatusCode(StatusCodeEnums.BUSINESS_ERROR.getCode());
			kBankHeaderResponse.setErrorVect(errors);
			response.setKbankHeader(kBankHeaderResponse);
		}else{
			try{
				response = idvaService.invalidateVerifyStatus(request);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.SUCCESS.getCode());
			}catch(IDVAException idvae){
//				LOGGER.error(idvae.toString(), idvae);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.BUSINESS_ERROR.getCode());
				errors = new ArrayList<Error>(); 
				error = new Error();
				error.setErrorAppId(String.valueOf(ApplicationConfig.APP_ID_IDVA));
				error.setErrorAppAbbrv(ApplicationConfig.APP_NAME_IDVA);
				error.setErrorCode("3000");
				error.setErrorDesc(idvae.getDesc());
				error.setErrorCode(idvae.getCode());
				errors.add(error);
				kBankHeaderResponse.setErrorVect(errors);
				response.setKbankHeader(kBankHeaderResponse);
			}catch(Exception e){
				LOGGER.error(e.toString(), e);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.SYSTEM_ERROR.getCode());
				errors = new ArrayList<Error>();
				error = new Error();
				error.setErrorAppId(String.valueOf(ApplicationConfig.APP_ID_IDVA));
				error.setErrorDesc("System error : " + e.toString());
				error.setErrorAppAbbrv(ApplicationConfig.APP_NAME_IDVA);
				error.setErrorCode(StatusCodeEnums.SYSTEM_ERROR.getCode());
				errors.add(error);
				kBankHeaderResponse.setErrorVect(errors);
				response.setKbankHeader(kBankHeaderResponse);
			}
		}
		genKbankHeaderInvalidate(request, response);
		try{
			LOGGER.info(String.format("RESPONSE Invalidate : %s", mapper.writeValueAsString(getInvalidateVerifyStatusResponseLog(response))));	
		}catch(Exception e){
			LOGGER.info(String.format("Cannot log RESPONSE Invalidate. Error = %s",e.getMessage()));
		}
		ServiceUtil.logResponse(response,uuid,key);
		IdvaLog idvalog = setLogValidate(request,response);
		ELKLogCustomField.elkLogInfo(ELKLOG , idvalog);
		return response;
	}
	
	private ArrayList<Error> validateRequestInquiry(InquiryVerifyRequest request){
		String cvrsAppCode = String.valueOf(ApplicationConfig.APP_ID_IDVA);

		
		if(request == null){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1000","InquiryVerifyRequest is null.", ERROR_SERVERITY);
			errors.add(error);
			return errors;
		}
		
		errors.addAll(validateRequestHeader(cvrsAppCode, ApplicationConfig.IDVA_SERVICE_01_CODE,request.getKbankHeader()));
		
		if ( StringUtils.isEmpty(request.getRefId()) || null == request.getRefId() ) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2001",ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"), ERROR_SERVERITY);
			errors.add(error);
		}
		
		if (StringUtils.isNotEmpty(request.getRefId()) && request.getRefId().trim().length() > 20) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2002",
					"refID invalid length. expected 20 digit.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if( request.getReferDocumentFlag() == null || StringUtils.isEmpty(request.getReferDocumentFlag()) ){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2003","referDoc flag Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if (StringUtils.isNotEmpty(request.getReferDocumentFlag()) && request.getReferDocumentFlag().trim().length() != 1) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2004",
					"referDoc invalid length. expected 1 digit.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if( ("Y".equals(request.getReferDocumentFlag()) && request.getDocuments() == null) 
				|| ("Y".equals(request.getReferDocumentFlag())  && request.getDocuments() != null && request.getDocuments().get(0) == null) ){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2005", "referDoc flag = true documents Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		
		List<DocumentRequest> chkDocs = request.getDocuments();
		
		if(chkDocs != null && chkDocs.size() > 50){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2006", "document list segment more than 50", ERROR_SERVERITY);
			errors.add(error);
		}
		
//		for(int i = 0 ; i < chkDocs.size() ; i++){
//			if(chkDocs.get(i) == null){
//				continue;
//			}
//			if(chkDocs.get(i).getDocumentType() == null || StringUtils.isEmpty(chkDocs.get(i).getDocumentType())) {
//				error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2007", String.format("document list %s document type cannot be null", i), ERROR_SERVERITY);
//				errors.add(error);
//			}
//			if (StringUtils.isNotEmpty(chkDocs.get(i).getDocumentType()) && chkDocs.get(i).getDocumentType().trim().length() > 2) {
//				error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2008",
//						String.format("document list %s document type invalid length. expected 2 digit.", i), ERROR_SERVERITY);
//				errors.add(error);
//			}
//			if(chkDocs.get(i).getDocumentId() == null || StringUtils.isEmpty(chkDocs.get(i).getDocumentId())) {
//				error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2009", String.format("document list %s document id cannot be null", i), ERROR_SERVERITY);
//				errors.add(error);
//			}
//			if (StringUtils.isNotEmpty(chkDocs.get(i).getDocumentId()) && chkDocs.get(i).getDocumentId().trim().length() > 20) {
//				error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2010",
//						String.format("document list %s document id invalid length. expected 20 digit.", i), ERROR_SERVERITY);
//				errors.add(error);
//			}
//		}
		
		return errors;
	}
	
	private ArrayList<Error> validateRequestInquiryWithServices(InquiryVerifyRequest request){
		String cvrsAppCode = String.valueOf(ApplicationConfig.APP_ID_IDVA);

		
		if(request == null){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1000","InquiryVerifyRequest is null.", ERROR_SERVERITY);
			errors.add(error);
			return errors;
		}
		
		errors.addAll(validateRequestHeader(cvrsAppCode, ApplicationConfig.IDVA_SERVICE_03_CODE,request.getKbankHeader()));
		
		if ( StringUtils.isEmpty(request.getRefId()) || null == request.getRefId() ) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2001",ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"), ERROR_SERVERITY);
			errors.add(error);
		}
		
		if (StringUtils.isNotEmpty(request.getRefId()) && request.getRefId().trim().length() > 20) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2002",
					"refID invalid length. expected 20 digit.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if( request.getReferDocumentFlag() == null || StringUtils.isEmpty(request.getReferDocumentFlag()) ){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2003","referDoc flag Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if (StringUtils.isNotEmpty(request.getReferDocumentFlag()) && request.getReferDocumentFlag().trim().length() != 1) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2004",
					"referDoc invalid length. expected 1 digit.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if( ("Y".equals(request.getReferDocumentFlag()) && request.getDocuments() == null) 
				|| ("Y".equals(request.getReferDocumentFlag())  && request.getDocuments() != null && request.getDocuments().get(0) == null) ){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2005", "referDoc flag = true documents Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		List<DocumentRequest> chkDocs = request.getDocuments();
		
		if(chkDocs != null && chkDocs.size() > 50){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2006", "document list segment more than 50", ERROR_SERVERITY);
			errors.add(error);
		}
		
		List<ServiceRequest> chkSers = request.getServiceRequest();
		if(chkSers == null){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2007", "services Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		} 
		else if(chkSers.size() > 0){
			for(ServiceRequest sv : chkSers){
				if(null == sv.getCode()){
					error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2007", "services Cannot be null.", ERROR_SERVERITY);
					errors.add(error);
					break;
				} else if(!SERVICE_OLD_OPEN_ACC_ID.equals(sv.getCode()) 
						&& !SERVICE_NEW_OPEN_ACC_ID.equals(sv.getCode())
						&& !SERVICE_NDID_ID.equals(sv.getCode())) {
					error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2008", "No service implement yet.", ERROR_SERVERITY);
					errors.add(error);
					break;
				}
			}
		}
		
		return errors;
	}
	
	private ArrayList<Error> validateRequestInquiryByAccountNo(InquiryVerifyRequest request){
		String cvrsAppCode = String.valueOf(ApplicationConfig.APP_ID_IDVA);

		
		if(request == null){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1000","InquiryVerifyRequest is null.", ERROR_SERVERITY);
			errors.add(error);
			return errors;
		}
		
		errors.addAll(validateRequestHeader(cvrsAppCode, ApplicationConfig.IDVA_SERVICE_04_CODE,request.getKbankHeader()));
		
		if ( StringUtils.isEmpty(request.getAccountNo()) || null == request.getAccountNo() ) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2009",ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"), ERROR_SERVERITY);
			errors.add(error);
		}
		
		if( request.getReferDocumentFlag() == null || StringUtils.isEmpty(request.getReferDocumentFlag()) ){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2003","referDoc flag Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if (StringUtils.isNotEmpty(request.getReferDocumentFlag()) && request.getReferDocumentFlag().trim().length() != 1) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2004",
					"referDoc invalid length. expected 1 digit.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if( ("Y".equals(request.getReferDocumentFlag()) && request.getDocuments() == null) 
				|| ("Y".equals(request.getReferDocumentFlag())  && request.getDocuments() != null && request.getDocuments().get(0) == null) ){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2005", "referDoc flag = true documents Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		List<DocumentRequest> chkDocs = request.getDocuments();
		
		if(chkDocs != null && chkDocs.size() > 50){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2006", "document list segment more than 50", ERROR_SERVERITY);
			errors.add(error);
		}
		
		List<ServiceRequest> chkSers = request.getServiceRequest();
		if(chkSers == null){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2007", "services Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		} 
		else if(chkSers.size() > 0){
			for(ServiceRequest sv : chkSers){
				if(null == sv.getCode()){
					error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2007", "services Cannot be null.", ERROR_SERVERITY);
					errors.add(error);
					break;
				} else if(!SERVICE_OLD_OPEN_ACC_ID.equals(sv.getCode()) 
						&& !SERVICE_NEW_OPEN_ACC_ID.equals(sv.getCode())
						&& !SERVICE_NDID_ID.equals(sv.getCode())) {
					error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2008", "No service implement yet.", ERROR_SERVERITY);
					errors.add(error);
					break;
				}
			}
		}
		
		return errors;
	}
	
	private ArrayList<Error> validateInvalidate(InvalidateVerifyStatusRequest request){
		String cvrsAppCode = String.valueOf(ApplicationConfig.APP_ID_IDVA);
		
		if (request == null) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1000","InvalidateVerifyStatusRequest is null.", ERROR_SERVERITY);
			errors.add(error);
			return errors;
		}
		
		errors.addAll(validateRequestHeader(cvrsAppCode, ApplicationConfig.IDVA_SERVICE_02_CODE,request.getKbankHeader()));
		
		if ( StringUtils.isEmpty(request.getRefId()) || null == request.getRefId() ) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2001",ApplicationConfig.RB.getString("ERROR_MISSING_MANDATORY_FIELD"), ERROR_SERVERITY);
			errors.add(error);
		}
		if (StringUtils.isNotEmpty(request.getRefId()) && request.getRefId().trim().length() > 20) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2002",
					"refID invalid length. expected 20 digit.", ERROR_SERVERITY);
			errors.add(error);
		}

		if( request.getReferDocumentFlag() == null || StringUtils.isEmpty(request.getReferDocumentFlag()) ){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2003","referDoc flag Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if (StringUtils.isNotEmpty(request.getReferDocumentFlag()) && request.getReferDocumentFlag().trim().length() != 1) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2004",
					"referDoc invalid length. expected 1 digit.", ERROR_SERVERITY);
			errors.add(error);
		}
		
		if( ("Y".equals(request.getReferDocumentFlag()) && request.getDocuments() == null) 
				|| ("Y".equals(request.getReferDocumentFlag())  && request.getDocuments() != null && request.getDocuments().get(0) == null) ){
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2005", "referDoc flag = true documents Cannot be null.", ERROR_SERVERITY);
			errors.add(error);
		}
		
//		if( request.getTransDesc() == null || StringUtils.isEmpty(request.getTransDesc()) ){
//			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2006", "transDesc Cannot be null.", ERROR_SERVERITY);
//			errors.add(error);
//		}
//		
//		if (StringUtils.isNotEmpty(request.getTransDesc()) && request.getTransDesc().trim().length() > 255) {
//			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2007",
//					"tranDesc invalid length. expected 255 digit.", ERROR_SERVERITY);
//			errors.add(error);
//		}
//		
//		if( request.getAccountNo() == null || StringUtils.isEmpty(request.getAccountNo()) ){
//			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2008", "accountNo Cannot be null.", ERROR_SERVERITY);
//			errors.add(error);
//		}
//		
//		if (StringUtils.isNotEmpty(request.getAccountNo()) && request.getAccountNo().trim().length() > 20) {
//			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2009",
//					"accountNo invalid length. expected 20 digit.", ERROR_SERVERITY);
//			errors.add(error);
//		}
		
//		List<DocumentRequest> chkDocs = request.getDocuments();
//		
//		if(chkDocs != null && chkDocs.size() > 50){
//			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2010", "document list segment more than 50", ERROR_SERVERITY);
//			errors.add(error);
//		}
		
//		for(int i = 0 ; i < chkDocs.size() ; i++){
//			if(chkDocs.get(i) == null){
//				continue;
//			}
//			if(chkDocs.get(i).getDocumentType() == null || StringUtils.isEmpty(chkDocs.get(i).getDocumentType())) {
//				error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2011", String.format("document list %s document type cannot be null", i), ERROR_SERVERITY);
//				errors.add(error);
//			}
//			if (StringUtils.isNotEmpty(chkDocs.get(i).getDocumentType()) && chkDocs.get(i).getDocumentType().trim().length() > 2) {
//				error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2012",
//						String.format("document list %s document type invalid length. expected 2 digit.", i), ERROR_SERVERITY);
//				errors.add(error);
//			}
//			if(chkDocs.get(i).getDocumentId() == null || StringUtils.isEmpty(chkDocs.get(i).getDocumentId())) {
//				error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2013", String.format("document list %s document id cannot be null", i), ERROR_SERVERITY);
//				errors.add(error);
//			}
//			if (StringUtils.isNotEmpty(chkDocs.get(i).getDocumentId()) && chkDocs.get(i).getDocumentId().trim().length() > 20) {
//				error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "2014",
//						String.format("document list %s document id invalid length. expected 20 digit.", i), ERROR_SERVERITY);
//				errors.add(error);
//			}
//		}
		
		return errors;
	}
	
	private List<Error> validateRequestHeader(String cvrsAppCode, String funcNm,
			KBankHeaderRequest kBankHeaderRequest) {

		Error error = null;
		ArrayList<Error> errors = new ArrayList<Error>();

		if (StringUtils.isEmpty(kBankHeaderRequest.getFuncNm())) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1001",
					"Function number is empty.", ERROR_SERVERITY);
			errors.add(error);
		}

		if (StringUtils.isNotEmpty(kBankHeaderRequest.getFuncNm()) && !kBankHeaderRequest.getFuncNm().equals(funcNm)) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1002",
					"Function number invalid : [" + kBankHeaderRequest.getFuncNm() + "]. expected '" + funcNm + "'",
					ERROR_SERVERITY);
			errors.add(error);
		}

		if (StringUtils.isEmpty(kBankHeaderRequest.getRqUID())) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1003",
					"Request id is empty.", ERROR_SERVERITY);
			errors.add(error);
		}

		if (kBankHeaderRequest.getRqDt() == null) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1004",
					"Request date is empty.", ERROR_SERVERITY);
			errors.add(error);
		}

		if (StringUtils.isEmpty(kBankHeaderRequest.getRqAppId())) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1005",
					"Request application id is empty.", ERROR_SERVERITY);
			errors.add(error);
		}

		if (StringUtils.isEmpty(kBankHeaderRequest.getUserId())) {
			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1006",
					"Request user id is empty.", ERROR_SERVERITY);
			errors.add(error);
		}

//		if (StringUtils.isEmpty(kBankHeaderRequest.getCorrID())) {
//			error = new Error(cvrsAppCode, ApplicationConfig.APP_NAME_IDVA, "1009",
//					"Request correlation id is empty.", ERROR_SERVERITY);
//			errors.add(error);
//		}
		return errors;
	}
	
	private void genKbankHeaderInquiry(InquiryVerifyRequest request ,InquiryVerifyResponse response){
		kBankHeaderRequest = request.getKbankHeader();
		kBankHeaderResponse.setFuncNm(kBankHeaderRequest.getFuncNm());
		kBankHeaderResponse.setRqUID(kBankHeaderRequest.getRqUID());
		kBankHeaderResponse.setRsAppId(kBankHeaderRequest.getRqAppId());
		kBankHeaderResponse.setRsDt(new Date());
		kBankHeaderResponse.setRsUID(kBankHeaderRequest.getRqUID());
		kBankHeaderResponse.setRegAuthLevel(kBankHeaderRequest.getAuthLevel());
		kBankHeaderResponse.setReqAuthUserId(kBankHeaderRequest.getAuthUserId());
		kBankHeaderResponse.setCorrID(kBankHeaderRequest.getCorrID());
		response.setKbankHeader(kBankHeaderResponse);
	}
	
	private void genKbankHeaderInquiryWithServices(InquiryVerifyRequest request ,InquiryVerifyWithServicesResponse response){
		kBankHeaderRequest = request.getKbankHeader();
		kBankHeaderResponse.setFuncNm(kBankHeaderRequest.getFuncNm());
		kBankHeaderResponse.setRqUID(kBankHeaderRequest.getRqUID());
		kBankHeaderResponse.setRsAppId(kBankHeaderRequest.getRqAppId());
		kBankHeaderResponse.setRsDt(new Date());
		kBankHeaderResponse.setRsUID(kBankHeaderRequest.getRqUID());
		kBankHeaderResponse.setRegAuthLevel(kBankHeaderRequest.getAuthLevel());
		kBankHeaderResponse.setReqAuthUserId(kBankHeaderRequest.getAuthUserId());
		kBankHeaderResponse.setCorrID(kBankHeaderRequest.getCorrID());
		response.setKbankHeader(kBankHeaderResponse);
	}
	
	private void genKbankHeaderInquiryByAccountNo(InquiryVerifyRequest request ,InquiryVerifyByAccountNoResponse response){
		kBankHeaderRequest = request.getKbankHeader();
		kBankHeaderResponse.setFuncNm(kBankHeaderRequest.getFuncNm());
		kBankHeaderResponse.setRqUID(kBankHeaderRequest.getRqUID());
		kBankHeaderResponse.setRsAppId(kBankHeaderRequest.getRqAppId());
		kBankHeaderResponse.setRsDt(new Date());
		kBankHeaderResponse.setRsUID(kBankHeaderRequest.getRqUID());
		kBankHeaderResponse.setRegAuthLevel(kBankHeaderRequest.getAuthLevel());
		kBankHeaderResponse.setReqAuthUserId(kBankHeaderRequest.getAuthUserId());
		kBankHeaderResponse.setCorrID(kBankHeaderRequest.getCorrID());
		response.setKbankHeader(kBankHeaderResponse);
	}
	
	private void genKbankHeaderInvalidate(InvalidateVerifyStatusRequest request ,InvalidateVerifyStatusResponse response){
		kBankHeaderRequest = request.getKbankHeader();
		kBankHeaderResponse.setFuncNm(kBankHeaderRequest.getFuncNm());
		kBankHeaderResponse.setRqUID(kBankHeaderRequest.getRqUID());
		kBankHeaderResponse.setRsAppId(kBankHeaderRequest.getRqAppId());
		kBankHeaderResponse.setRsDt(new Date());
		kBankHeaderResponse.setRsUID(kBankHeaderRequest.getRqUID());
		kBankHeaderResponse.setRegAuthLevel(kBankHeaderRequest.getAuthLevel());
		kBankHeaderResponse.setReqAuthUserId(kBankHeaderRequest.getAuthUserId());
		kBankHeaderResponse.setCorrID(kBankHeaderRequest.getCorrID());
		response.setKbankHeader(kBankHeaderResponse);
	}

	private String getServiceDescription(String code){
		String desc = "";
		if ("01".equals(code)) desc = "เปิดบัญชีเก่า";
		else if ("02".equals(code)) desc = "เปิดบัญชีใหม่";
		else if ("03".equals(code)) desc = "Enroll NDID";
		return desc;
	}

	@Override
	public InquiryVerifyByAccountNoResponse InquiryVerifyByAccountNo(InquiryVerifyRequest request) {
		try{
			LOGGER.info(String.format("REQUEST InquiryVerify : %s", mapper.writeValueAsString(getInquiryVerifyRequestLog(request))));	
		}catch(Exception e){
			LOGGER.info(String.format("Cannot log REQUEST InquiryVerify. Error = %s",e.getMessage()));
		}
		String uuid = UUID.randomUUID().toString();
		String key = StringUtils.trimToEmpty(request.getKbankHeader().getRqUID());
		ServiceUtil.logRequest(request,uuid,key);
		IDVAService idvaService = StaticContextHolder.getBean(IDVAService.class);
		
		InquiryVerifyByAccountNoResponse response = new InquiryVerifyByAccountNoResponse();
		kBankHeaderResponse = new KBankHeaderResponse();
		errors = new ArrayList<>();
		errors = validateRequestInquiryByAccountNo(request);
		if(errors.size() > 0){
			
			LOGGER.info(String.format("INVALID_REQUEST [Error size=%s]", errors.size()));
			kBankHeaderResponse.setStatusCode(StatusCodeEnums.BUSINESS_ERROR.getCode());
			kBankHeaderResponse.setErrorVect(errors);
			
			
			List<ServiceRequest> serviceRequest = request.getServiceRequest();
			if(null != serviceRequest){
				for (ServiceRequest rq : serviceRequest) {
					List<SereviceResponse> services = new ArrayList<SereviceResponse>();
					SereviceResponse service = new SereviceResponse();
					service.setCode(rq.getCode());
					service.setDescription(getServiceDescription(rq.getCode()));
					service.setStatus(StatusWS.RED.getCode());
					services.add(service);
					response.setServices(services);
				}
			}
			response.setKbankHeader(kBankHeaderResponse);
			response.setAccountNo(StringUtils.trimToEmpty(request.getAccountNo()));
			response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
			response.setNumberOfValid(0);
			response.setNumberOfInValid(0);
			response.setNumberOfRefId(0);
			
		}else{
			try{
				response = idvaService.inquiryVerifyByAccountNo(request);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.SUCCESS.getCode());
			}catch(IDVAException idvae){
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.BUSINESS_ERROR.getCode());
				errors = new ArrayList<Error>();
				error = new Error();
				error.setErrorAppId(String.valueOf(ApplicationConfig.APP_ID_IDVA));
				error.setErrorAppAbbrv(ApplicationConfig.APP_NAME_IDVA);
				error.setErrorDesc(idvae.getDesc());
				error.setErrorCode(idvae.getCode());
				errors.add(error);
				kBankHeaderResponse.setErrorVect(errors);
				
				List<SereviceResponse> services = new ArrayList<SereviceResponse>();
				List<ServiceRequest> serviceRequest = request.getServiceRequest();
				for (ServiceRequest rq : serviceRequest) {
					SereviceResponse service = new SereviceResponse();
					service.setCode(rq.getCode());
					service.setDescription(getServiceDescription(rq.getCode()));
					service.setStatus(StatusWS.RED.getCode());
					services.add(service);
				}
				
				response.setKbankHeader(kBankHeaderResponse);
				response.setAccountNo(StringUtils.trimToEmpty(request.getAccountNo()));
				response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
				response.setNumberOfValid(0);
				response.setNumberOfInValid(0);
				response.setNumberOfRefId(0);
				response.setServices(services);
			} catch( Exception e ) {
				LOGGER.error(e.toString(), e);
				kBankHeaderResponse.setStatusCode(StatusCodeEnums.SYSTEM_ERROR.getCode());
				errors = new ArrayList<Error>();
				error = new Error();
				error.setErrorAppId(String.valueOf(ApplicationConfig.APP_ID_IDVA));
				error.setErrorAppAbbrv(ApplicationConfig.APP_NAME_IDVA);
				error.setErrorCode(StatusCodeEnums.SYSTEM_ERROR.getCode());
				error.setErrorDesc("System error : " + e.toString());
				errors.add(error);
				kBankHeaderResponse.setErrorVect(errors);
				
				List<SereviceResponse> services = new ArrayList<SereviceResponse>();
				List<ServiceRequest> serviceRequest = request.getServiceRequest();
				for (ServiceRequest rq : serviceRequest) {
					SereviceResponse service = new SereviceResponse();
					service.setCode(rq.getCode());
					service.setDescription(getServiceDescription(rq.getCode()));
					service.setStatus(StatusWS.RED.getCode());
					services.add(service);
				}
				
				response.setKbankHeader(kBankHeaderResponse);
				response.setAccountNo(StringUtils.trimToEmpty(request.getAccountNo()));
				response.setReferDocumentFlag(StringUtils.trimToEmpty(request.getReferDocumentFlag()));
				response.setNumberOfValid(0);
				response.setNumberOfInValid(0);
				response.setNumberOfRefId(0);
				response.setServices(services);
			}
		}
		genKbankHeaderInquiryByAccountNo(request, response);
		try{
			LOGGER.info(String.format("RESPONSE InquiryVerify : %s", mapper.writeValueAsString(getInquiryVerifyByAccountNoResponsetLog(response))));	
		}catch(Exception e){
			LOGGER.info(String.format("Cannot log RESPONSE InquiryVerify. Error = %s",e.getMessage()));
		}
		ServiceUtil.logResponse(response,uuid,key);
		IdvaLog idvalog = setLogValidate(request,response);
		ELKLogCustomField.elkLogInfo(ELKLOG , idvalog);
		return response;
	}
	
	public InquiryVerifyResponse getInquiryVerifyResponsetLog(InquiryVerifyResponse response) {
		InquiryVerifyResponse responseLog = new InquiryVerifyResponse();
		responseLog.setKbankHeader(response.getKbankHeader());
		responseLog.setRefId(response.getRefId());
		responseLog.setReferDocumentFlag(response.getReferDocumentFlag());
		responseLog.setNumberOfRefId(response.getNumberOfRefId());
		responseLog.setNumberOfInValid(response.getNumberOfInValid());
		responseLog.setNumberOfValid(response.getNumberOfValid());
		responseLog.setStatus(response.getStatus());
		return responseLog;
	}
	
	public InquiryVerifyWithServicesResponse getInquiryVerifyWithServicesResponsetLog(InquiryVerifyWithServicesResponse response) {
		InquiryVerifyWithServicesResponse responseLog = new InquiryVerifyWithServicesResponse();
		responseLog.setKbankHeader(response.getKbankHeader());
		responseLog.setRefId(response.getRefId());
		responseLog.setReferDocumentFlag(response.getReferDocumentFlag());
		responseLog.setNumberOfRefId(response.getNumberOfRefId());
		responseLog.setNumberOfInValid(response.getNumberOfInValid());
		responseLog.setNumberOfValid(response.getNumberOfValid());
		return responseLog;
	}
	
	public InquiryVerifyByAccountNoResponse getInquiryVerifyByAccountNoResponsetLog(InquiryVerifyByAccountNoResponse response) {
		InquiryVerifyByAccountNoResponse responseLog = new InquiryVerifyByAccountNoResponse();
		responseLog.setKbankHeader(response.getKbankHeader());
		responseLog.setRefId(response.getRefId());
		responseLog.setReferDocumentFlag(response.getReferDocumentFlag());
		responseLog.setNumberOfRefId(response.getNumberOfRefId());
		responseLog.setNumberOfInValid(response.getNumberOfInValid());
		responseLog.setNumberOfValid(response.getNumberOfValid());
		return responseLog;
	}
	
	public InquiryVerifyRequest getInquiryVerifyRequestLog(InquiryVerifyRequest request) {
		InquiryVerifyRequest requestLog = new InquiryVerifyRequest();
		requestLog.setKbankHeader(request.getKbankHeader());
		requestLog.setRefId(request.getRefId());
		requestLog.setReferDocumentFlag(request.getReferDocumentFlag());
		requestLog.setServiceRequest(request.getServiceRequest());
		return requestLog;
	}
	
	public InvalidateVerifyStatusRequest getInvalidateVerifyStatusRequestLog(InvalidateVerifyStatusRequest request) {
		InvalidateVerifyStatusRequest requestLog = new InvalidateVerifyStatusRequest();
		requestLog.setKbankHeader(request.getKbankHeader());
		requestLog.setRefId(request.getRefId());
		requestLog.setReferDocumentFlag(request.getReferDocumentFlag());
		requestLog.setTransDesc(request.getTransDesc());
		requestLog.setTransTypeCode(request.getTransTypeCode());
		requestLog.setTransTypeDesc(request.getTransTypeDesc());
		return requestLog;
	}
	
	public InvalidateVerifyStatusResponse getInvalidateVerifyStatusResponseLog(InvalidateVerifyStatusResponse response) {
		InvalidateVerifyStatusResponse responseLog = new InvalidateVerifyStatusResponse();
		responseLog.setKbankHeader(response.getKbankHeader());
		return responseLog;
	}
	
	
	private IdvaLog setLogValidate(InquiryVerifyRequest request,Object response) {
		IdvaLog idvaLog = null;
		try {
			String jsonRs = "N".equalsIgnoreCase(getConfigValue("encode.elk.flg")) ? new Gson().toJson(response) : Base64.getEncoder().encodeToString(new Gson().toJson(response).getBytes()) ;

				idvaLog = new IdvaLog(
						request.getKbankHeader() != null ? request.getKbankHeader().getFuncNm() : "",
						request.getKbankHeader() != null ? request.getKbankHeader().getRqUID() : "",	
						request.getKbankHeader() != null ? request.getKbankHeader().getRqDt().toString() : "",
						request.getKbankHeader() != null ? request.getKbankHeader().getRqAppId() : "",	
						request.getRefId(),
						jsonRs
						);
			
			
		}catch(Exception e) {
			LOGGER.info(e.getMessage());
		}
		return idvaLog;
	}
	
	private IdvaLog setLogValidate(InvalidateVerifyStatusRequest request,Object response) {
		IdvaLog idvaLog = null;
		try {
			String jsonRs = "N".equalsIgnoreCase(getConfigValue("encode.elk.flg")) ? new Gson().toJson(response) : Base64.getEncoder().encodeToString(new Gson().toJson(response).getBytes()) ;

				idvaLog = new IdvaLog(
						request.getKbankHeader() != null ? request.getKbankHeader().getFuncNm() : "",
						request.getKbankHeader() != null ? request.getKbankHeader().getRqUID() : "",	
						request.getKbankHeader() != null ? request.getKbankHeader().getRqDt().toString() : "",
						request.getKbankHeader() != null ? request.getKbankHeader().getRqAppId() : "",	
						request.getRefId(),
						jsonRs
						);
			
			
		}catch(Exception e) {
			LOGGER.info(e.getMessage());
		}
		return idvaLog;
	}
	
}
