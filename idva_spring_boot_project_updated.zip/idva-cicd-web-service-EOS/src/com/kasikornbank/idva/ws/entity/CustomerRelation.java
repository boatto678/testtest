package com.kasikornbank.idva.ws.entity;

public class CustomerRelation {
	
	private String relCd;
	private String relCisId;
	
	public String getRelCd() {
		return relCd;
	}
	public void setRelCd(String relCd) {
		this.relCd = relCd;
	}
	public String getRelCisId() {
		return relCisId;
	}
	public void setRelCisId(String relCisId) {
		this.relCisId = relCisId;
	}
	
}
