package com.kasikornbank.idva.ws.entity.enums;

public enum ResponseStatusEnum {

	DATA_IS_QUALITY(9000, "Data is quality."), DATA_IS_NOT_QUALITY(9001, "Data is not quality."), OTHER_ERROR(9999, "Other error."), INVALID_PARAMETER(
			9005, "Invalide Parameter"), DATA_FOUND(9003, "Data found."), DATA_NOT_FOUND(9004, "Data not found.");

	private int responseCode;
	private String responseMsg;

	private ResponseStatusEnum(int responseCode, String responseMsg) {
		this.responseCode = responseCode;
		this.responseMsg = responseMsg;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

}
