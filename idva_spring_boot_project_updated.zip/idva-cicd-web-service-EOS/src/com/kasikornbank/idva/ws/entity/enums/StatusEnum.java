package com.kasikornbank.idva.ws.entity.enums;

public enum StatusEnum {
	YES("Y"), NO("N");
	private String code;

	private StatusEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
}
