package com.kasikornbank.idva.ws.entity;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="InvalidateVerifyStatusResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class InvalidateVerifyStatusResponse {

	private KBankHeaderResponse kbankHeader;

	public KBankHeaderResponse getKbankHeader() {
		return kbankHeader;
	}

	public void setKbankHeader(KBankHeaderResponse kbankHeader) {
		this.kbankHeader = kbankHeader;
	}
	
}
