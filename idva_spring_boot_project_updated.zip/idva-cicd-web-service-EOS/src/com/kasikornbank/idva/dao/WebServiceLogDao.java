package com.kasikornbank.idva.dao;

import static java.text.MessageFormat.format;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kasikornbank.idva.dao.domain.WebServiceLog;

@Repository("webServiceLogDao")
@Transactional
public class WebServiceLogDao implements IWebServiceLogDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	private static final String SQL_INSERT = "INSERT INTO WEB_SERVICE_LOG (UUID, KEY, XML, XML_TYPE, TRANSACTION_DATE) VALUES  (?,?,?,?,?)";

	@Override
	public boolean save(WebServiceLog t) {
		if (t == null) {
			throw new NullPointerException("webServiceLog is null.");
		}
		int row = jdbcTemplate.update(format(SQL_INSERT), t.getUuid(), t.getKey(), t.getXml(), t.getXmlType().name(),
				new java.sql.Timestamp(t.getTransactionDate().getTime()));
		return row > 0;
	}

}
