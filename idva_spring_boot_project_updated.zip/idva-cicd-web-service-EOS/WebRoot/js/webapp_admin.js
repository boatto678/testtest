$(document)
		.ajaxStart(
				function() {
					$
							.blockUI({
								message : '<table><tr><td><img src="../images/loading.gif" /></td><td><span class="text-paging"> Please wait while the system is processing your request...<span><td></tr></table>',
								css : {
									border : 'solide',
									padding : '15px',
									backgroundColor : '#fff',
									'-webkit-border-radius' : '4px',
									'-moz-border-radius' : '4px',
									opacity : 2,
									color : '#F0F0E8'
								}
							});
				}).ajaxStop(function() {
			setTimeout(function() {
				$.unblockUI();
			}, 50);
		});

var WebAppAdmin = {

	init : function() {
	},
	clearCache : function() {

		$.ajax({
			type : 'GET',
			url : '../admin/clearCache',
			dataType : 'json',
			data : {},
			success : function(data) {
				var html = '<table class="gridtable">';
				html += '<tr><th> Clear cache : ' + data.status + '</th></tr>';
				html += '</table>';
				$('#divResult1').html(html);
				$('#divResult2').html('');
				$('#divResult3').html('');
				$('#divResult4').html('');
			}
		});

	},
	viewLog : function() {

		var errorId = $('#txtLogID').val();

		if (errorId == '' || errorId.length == 0) {
			alert("Validate : Error id is required.");
			$('#errorId').focus();
			return;
		}

		$.ajax({
			type : 'GET',
			url : '../admin/logsViewByErrorId',
			dataType : 'json',
			data : {
				errorId : errorId
			},
			success : function(data) {
				// alert(data.status);
				var html = '<table class="gridtable">';
				html += '<tr><th> Transaction ID : ' + errorId + '</th></tr>';
				var content = '';
				content += '<tr><td style="color:red;" >' + data.error
						+ '</td></tr>';
				html += content;
				html += '</table>';

				$('#divResult1').html(html);
				$('#divResult2').html('');
				$('#divResult3').html('');
				$('#divResult4').html('');

			}
		});

	},

	callByAccount : function() {

		var accountNo = $('#txtAccount').val();

		if (accountNo == '' || accountNo.length == 0) {
			alert("Validate : Account No is required.");
			$('#txtAccount').focus();
			return;
		}

		$
				.ajax({
					type : 'GET',
					url : '../admin/callDIHService',
					dataType : 'json',
					data : {
						accountNo : accountNo
					},
					success : function(data) {
						if (data.status == 'OK') {
							var html = '<table><tr><td colspan="3"><b>Account My Ports</b></td></tr></table>';
							html += '<table class="gridtable">';
							html += '<tr>';
							html += '<th>accountNo</th>';
							html += '<th>accountType</th>';
							// html += '<td>status</td>';
							html += '<th>subOfAccount</th>';
							html += '<th>itemCode</th>';
							html += '</tr>';

							$(data.accountMyPorts).each(function(index, item) {
								html += '<tr>';
								html += '<td>' + item.accountNo + '</td>';
								html += '<td>' + item.accountType + '</td>';
								html += '<td>' + item.subOfAccount + '</td>';
								html += '<td>' + item.itemCode + '</td>';
								html += '</tr>';
							});
							html += '</table>';

							$('#divResult1').html(html);

							html = '<table><tr><td colspan="3"><b>Deposits</b></td></tr></table>';
							html += '<table class="gridtable">';
							html += '<tr>';
							html += '<th>accountNo</th>';
							html += '<th>accountType</th>';
							html += '<th>accountName Th</th>';
							html += '<th>accountName En</th>';
							html += '<th>accountBalance</th>';
							html += '<th>depositDue</th>';
							html += '<th>interestAmount</th>';
							html += '<th>ratio</th>';
							html += '<th>summaryType</th>';
							html += '</tr>';

							$(data.deposits).each(
									function(index, item) {
										html += '<tr>';
										html += '<td>' + item.accountNo
												+ '</td>';
										html += '<td>' + item.accountType
												+ '</td>';
										html += '<td>'
												+ item.accountName.thName
												+ '</td>';
										html += '<td>'
												+ item.accountName.enName
												+ '</td>';
										html += '<td>' + item.accountBalance
												+ '</td>';
										html += '<td>' + item.depositDue
												+ '</td>';
										html += '<td>' + item.interestAmount
												+ '</td>';
										html += '<td>' + item.ratio + '</td>';
										html += '<td>' + item.summaryType
												+ '</td>';
										html += '</tr>';
									});
							html += '</table>';

							$('#divResult2').html(html);

							html = '<table><tr><td colspan="3"><b>Funds</b></td></tr></table>';
							html += '<table class="gridtable">';
							html += '<tr>';
							html += '<th>fundId</th>';
							html += '<th>fundAccount</th>';
							html += '<th>subFundAccount</th>';
							html += '<th>fundUnitsOutstanding</th>';
							html += '<th>nav</th>';
							html += '<th>navDate</th>';
							html += '<th>averageCost</th>';
							html += '<th>fundCode</th>';
							html += '<th>riskLevel</th>';
							html += '</tr>';

							$(data.funds)
									.each(
											function(index, item) {
												html += '<tr>';
												html += '<td>' + item.fundId
														+ '</td>';
												html += '<td>'
														+ item.fundAccount
														+ '</td>';
												html += '<td>'
														+ item.subFundAccount
														+ '</td>';
												html += '<td>'
														+ item.fundUnitsOutstanding
														+ '</td>';
												html += '<td>' + item.nav
														+ '</td>';
												html += '<td>' + item.navDate
														+ '</td>';
												html += '<td>'
														+ item.averageCost
														+ '</td>';
												html += '<td>'
														+ item.fundCode.fundCodeName
														+ '</td>';
												html += '<td>' + item.riskLevel
														+ '</td>';
												html += '</tr>';
											});
							html += '</table>';

							$('#divResult3').html(html);

							html = '<table><tr><td colspan="3"><b>Securities</b></td></tr></table>';
							html += '<table class="gridtable">';
							html += '<tr>';
							html += '<th>accountNo</th>';
							html += '<th>subAccountNo</th>';
							html += '<th>secCode</th>';
							html += '<th>outstandingUnits</th>';
							html += '<th>averageCost</th>';
							html += '<th>marketPrice</th>';
							html += '<th>costAmount</th>';
							html += '<th>marketAmount</th>';
							html += '<th>marketPLAmount</th>';
							html += '<th>marketPLPercent</th>';
							html += '<th>typeOfSecCode</th>';
							html += '</tr>';

							$(data.securities)
									.each(
											function(index, item) {
												html += '<tr>';
												html += '<td>' + item.accountNo
														+ '</td>';
												html += '<td>'
														+ item.subAccountNo
														+ '</td>';
												html += '<td>' + item.secCode
														+ '</td>';
												html += '<td>'
														+ item.outstandingUnits
														+ '</td>';
												html += '<td>'
														+ item.averageCost
														+ '</td>';
												html += '<td>'
														+ item.marketPrice
														+ '</td>';
												html += '<td>'
														+ item.costAmount
														+ '</td>';
												html += '<td>'
														+ item.marketAmount
														+ '</td>';
												html += '<td>'
														+ item.marketPLAmount
														+ '</td>';
												html += '<td>'
														+ item.marketPLPercent
														+ '</td>';
												html += '<td>'
														+ item.typeOfSecCode
														+ '</td>';
												html += '</tr>';
											});
							html += '</table>';

							$('#divResult4').html(html);

						} else {
							var html = 'Error : ' + data.error;
							$('#divResult1').html(html);
							$('#divResult2').html('');
							$('#divResult3').html('');
							$('#divResult4').html('');
						}
					}
				});
	}
};

jQuery(function($) {
	WebAppAdmin.init();
	// WebAppAdmin.loadTable();
});
